# CD133⁺ glioblastoma stem cell phenotypic screening — machine learning framework

Code, data and results for an interpretable, leakage-controlled machine learning analysis of
PubChem BioAssay **AID 1345199**, submitted to the *Journal of Cheminformatics*.

Everything reported in the manuscript is generated from this repository. No value in the
paper is transcribed by hand: a verification script checks that every number in the
manuscript traces to a file in `results_export/`.

---

## What the analysis does

- Curates 3,401 assay parents from AID 1345199 with RDKit (salt stripping, charge
  neutralisation, parent-identity deduplication, stereo-annotation guards).
- Benchmarks **8 classifiers × 3 molecular representations × 2 splitting strategies = 48
  combinations** under one prespecified protocol: nested cross-validation, five outer folds
  for out-of-fold evaluation, five inner folds for the grid search, all preprocessing
  confined to training folds.
- Representations: 7 physicochemical descriptors, 1024-bit ECFP4, and their 1031-feature
  hybrid. Splits: stratified random, and Bemis–Murcko scaffold with groups preserved across
  outer folds, inner folds and tuning.
- Designates a **class-weighted Random Forest** on the seven descriptors, interprets it with
  interventional Tree SHAP and compound-level bootstrap importance intervals, and screens a
  repurposing library inside a descriptor-space applicability domain.

### Two deliberate choices worth knowing about

**Cost-sensitive class weighting, not oversampling.** Interpolating between binary
fingerprint bits produces vectors that correspond to no real molecule. Class weighting
generates no synthetic data. Oversampling is retained as a reported secondary benchmark, and
the comparison (appendix A11) shows the two are **equivalent in discrimination** — so no
performance advantage is claimed for the choice.

**The benchmark groups models; it does not rank them.** 24 of 42 adjacent pairs differ by
less than the uncertainty of repeated resampling. Models indistinguishable from the best in
their representation are marked in the tables, and the order among them carries no meaning.

---

## Quick start

```bash
git clone <REPOSITORY URL>
cd <REPOSITORY NAME>
pip install -r requirements.txt
```

### Option A — run the notebook (Colab or Jupyter)

Open `CD133_Cheminformatics_Colab.ipynb`, ensure the three data files sit beside it, and run
all cells. The run configuration cell controls cost:

| Flag | Default | Effect |
|---|---|---|
| `RUN_FULL_BENCHMARK` | `False` | `True` runs all 48 combinations (hours). `False` runs the 7-descriptor path only (~30 min) and still produces the designated model, its SHAP analysis and the screening. |
| `RUN_APPENDIX` | `True` | Appendices A1–A11, including the 20-repetition internal validation and the imbalance-framework comparison. |
| `SHAP_BACKGROUND_N` | `500` | Interventional Tree SHAP background size. |
| `IMBALANCE_STRATEGY` | `'class_weight'` | `'smote'` reproduces the secondary oversampling benchmark. |

### Option B — run headless

```bash
python3 export_runner.py run_production.py class_weight   # notebook -> script
./launch_production.sh                                    # with pre-flight checks
./launch_production.sh --resume                           # continue after an interruption
```

`export_runner.py` derives the script from the notebook, so the two cannot drift apart. It
refuses to export source containing an undefined name, and it carries the data-file
definitions through so the execution manifest records dataset checksums.

`launch_production.sh` refuses to start if the checkpoint directory is non-empty without
`--resume`, if the runner carries a debugging marker, or if a required setting is missing. It
reports the **genuine** Python exit status via `PIPESTATUS`, not `tee`'s.

---

## Reproducing the reported results

```bash
python3 verify_deposited_models.py p4_checkpoints_class_weight   # needs the Zenodo checkpoints
python3 audit_consistency.py results_export                      # 20 structural checks
python3 build_ms.py results_export Manuscript.docx               # regenerate the manuscript
python3 verify_ms.py results_export Manuscript.docx              # every number traces to an export
```

**Honest note on coverage.** `verify_deposited_models.py` recomputes predictions for the 16
seven-descriptor checkpoints and reports the other 32 as **skipped**, because the ECFP4 and
Hybrid feature matrices are not deposited. It prints its coverage percentage and exits
non-zero rather than claiming a clean bill of health. Independent refit reproducibility was
separately tested for four models; see `docs/AGENT_B_REPRODUCIBILITY_REPORT.md`.

---

## Layout

```
CD133_Cheminformatics_Colab.ipynb   the analysis; single source of truth
cd133_estimators.py                 cost-sensitive XGBoost (a module, so pickled
                                    checkpoints reload without running the notebook)
export_runner.py                    notebook -> headless script, with a NameError gate
launch_production.sh                launcher with pre-flight checks and honest exit status
launch_chunk.sh                     resume launcher; records chunk boundaries into the log
verify_deposited_models.py          checkpoint restoration verifier
audit_consistency.py                structural and language audit of the results/manuscript
build_ms.py / verify_ms.py          manuscript generation and number-provenance check
AID_1345199_...csv                  PubChem assay records (input)
External_Validation_Library.txt     benchmark compounds (input)
Broad_Institute_...Hub_Full.txt     repurposing library (input)
results_export/                     every value behind the manuscript, machine-readable
figures_submission/                 the 12 manuscript figures, 300 dpi PNG + vector PDF
production.log                      full execution log, both chunks
docs/                               defect register, tolerances, reproducibility report
```

### Not in this repository

| Artifact | Size | Where |
|---|---|---|
| 48 fitted model checkpoints | 276 MB | Zenodo — too large for git, and above the journal's additional-file cap |
| Curation provenance archives | 8.7 MB | Zenodo |

---

## Provenance

`results_export/execution_manifest.json` records, for the reported run: a SHA-256 of the
notebook, checksums of the three input files and the curated derivatives, every random seed
named by what it controls, the designated model configuration, partition sizes and
per-combination fingerprints, the software environment, per-chunk execution status, and
checksums of every output file.

The reported run executed in two chunks (the environment caps a background process at two
hours): all 48 combinations completed in chunk 1, which was then stopped by that cap; chunk 2
resumed from the fingerprinted checkpoints and completed the appendices, figures and export
with exit status 0. Both boundaries are recorded in `production.log`.
`results_export/checkpoint_restoration_failures.csv` is exported unconditionally, so an empty
file positively states that every checkpoint restored cleanly.

`docs/DEFECT_REGISTER.md` documents all 17 defects found during development, with root
causes, corrections and regression evidence — including the six that would have produced
wrong or mislabelled numbers, and the six that originated in the reproducibility
infrastructure itself.

---

## Environment

Python 3.13.18 with the versions pinned in `requirements.txt`, which were recorded
automatically during the reported run. `rdkit 2026.09.1`, `scikit-learn 1.9.1`,
`shap 0.54.1`, `xgboost 3.4.1`.

## Licence

`<LICENCE — add before publishing>`. The *Journal of Cheminformatics* requires an
OSI-approved licence for deposited code.

## Citation

`<Manuscript citation once accepted>`
Archived version: `<ZENODO DOI>`

## Contact

Dr Edmund Essah Ameyaw, Department of Pharmaceutical Sciences, Howard University College of
Pharmacy — edmundessah.ameyaw@howard.edu
