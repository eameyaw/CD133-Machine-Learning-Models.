"""Verify that deposited model checkpoints restore and reproduce their recorded predictions.

Condition 7 of the author's round-5 decision asks for restoration of deposited models to be
verified SEPARATELY from the analysis that produced them. This script is that check, and it
is deliberately standalone: it imports nothing from the notebook and defines no estimator
class of its own, so it exercises exactly what a third party experiences when they download
the package and load a model.

For every checkpoint it:
  1. loads it in this process, recording any failure rather than aborting;
  2. confirms the stored fingerprint is present (provenance recorded);
  3. re-runs the restored pipeline over the stored evaluation inputs and checks the
     predictions and ranking scores match the stored ones bit for bit.

Step 3 is the part that matters. A checkpoint can unpickle successfully and still be
unusable - a changed library can alter numerical behaviour without raising - so restoration
is only demonstrated by reproducing the recorded output, not by a successful import.

Usage:
    python3 verify_deposited_models.py [checkpoint_dir]

Exit status is non-zero if any checkpoint fails, so it can gate a release.
"""
import json
import os
import sys

import joblib
import numpy as np
import pandas as pd

# The deposited estimator module must be importable for pickles that reference it. It sits
# beside this script; isolated interpreters (-I, -P) drop the working directory from
# sys.path, so add it explicitly rather than assuming.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def verify(checkpoint_dir, descriptor_file='curated_descriptors.csv',
           label_file='curated_labels.csv'):
    x = pd.read_csv(descriptor_file, index_col=0)
    y = pd.read_csv(label_file, index_col=0)['PUBCHEM_ACTIVITY_OUTCOME']
    rows = []
    paths = sorted(p for p in os.listdir(checkpoint_dir) if p.endswith('.joblib'))
    if not paths:
        print(f'no checkpoints found in {checkpoint_dir}')
        return 1, pd.DataFrame()

    for name in paths:
        path = os.path.join(checkpoint_dir, name)
        record = {'Checkpoint': name, 'Restored': False, 'Fingerprint': None,
                  'Provenance recorded': False, 'Predictions reproduced': None,
                  'Scores reproduced': None, 'Scores bit-exact': None,
                  'Max score deviation': None, 'Rows checked': 0, 'Error': ''}
        try:
            blob = joblib.load(path)
        except Exception as error:
            record['Error'] = f'{type(error).__name__}: {error}'[:200]
            rows.append(record)
            print(f'FAIL  {name}\n      restoration failed: {record["Error"]}')
            continue
        record['Restored'] = True
        result = blob.get('result', blob) if isinstance(blob, dict) and 'result' in blob else blob
        record['Fingerprint'] = blob.get('fingerprint') if isinstance(blob, dict) else None
        record['Provenance recorded'] = record['Fingerprint'] is not None

        try:
            pipeline = result['pipeline']
            held = result['held_out']
            # The feature matrix a checkpoint was built from is identified by its stored
            # row index, so the recomputation uses the same compounds in the same order.
            inputs = x.loc[held.index].astype(float)
            n_expected = pipeline.named_steps['scaler'].n_features_in_
            if inputs.shape[1] != n_expected:
                record['Error'] = (f'descriptor file has {inputs.shape[1]} features, '
                                   f'checkpoint expects {n_expected}; '
                                   'fingerprint-only verification')
                rows.append(record)
                print(f'SKIP  {name}\n      {record["Error"]}')
                continue
            fresh_pred = pipeline.predict(inputs)
            record['Predictions reproduced'] = bool(
                np.array_equal(fresh_pred, held['Prediction'].to_numpy()))
            if hasattr(pipeline, 'predict_proba'):
                col = int(np.flatnonzero(np.asarray(pipeline.classes_) == 1)[0])
                fresh_score = pipeline.predict_proba(inputs)[:, col]
            else:
                fresh_score = pipeline.decision_function(inputs)
            # Predictions must match EXACTLY; scores to a tight numerical tolerance.
            # Bit-exact equality is the wrong test for scores: linear and kernel models
            # reach them through BLAS reductions whose summation order depends on thread
            # count, so recomputing on different hardware shifts the last bits without
            # anything being wrong. Measured here, that noise is 2e-16 to 1e-13, while
            # the tree models are bit-exact because they perform no such reduction. The
            # observed deviation is recorded rather than merely compared, so a reader can
            # see it instead of taking a pass on trust - and a genuine restoration
            # failure would exceed this tolerance by many orders of magnitude.
            stored_score = held['Ranking score'].to_numpy()
            deviation = float(np.max(np.abs(fresh_score - stored_score))) if len(stored_score) else 0.0
            record['Max score deviation'] = deviation
            record['Scores bit-exact'] = bool(np.array_equal(fresh_score, stored_score))
            record['Scores reproduced'] = bool(np.allclose(
                fresh_score, stored_score, rtol=1e-12, atol=1e-12))
            record['Rows checked'] = int(len(inputs))
        except Exception as error:
            record['Error'] = f'{type(error).__name__}: {error}'[:200]

        ok = record['Predictions reproduced'] and record['Scores reproduced']
        print(f'{"PASS" if ok else "FAIL"}  {name}\n'
              f'      fingerprint {record["Fingerprint"]}  rows {record["Rows checked"]}  '
              f'predictions {record["Predictions reproduced"]}  '
              f'scores {record["Scores reproduced"]}  '
              f'max deviation {record["Max score deviation"]:.3e}'
              f'{" (bit-exact)" if record["Scores bit-exact"] else ""}'
              + (f'\n      {record["Error"]}' if record['Error'] else ''))
        rows.append(record)

    table = pd.DataFrame(rows)
    checked = table[table['Predictions reproduced'].notna()]
    failures = checked[~(checked['Predictions reproduced'] & checked['Scores reproduced'])]
    unreadable = table[~table['Restored']]
    no_provenance = table[table['Restored'] & ~table['Provenance recorded']]

    # Skips are counted and surfaced, not folded into a pass. The earlier version printed
    # "all deposited models restored and reproduced their recorded output" and exited 0
    # while silently treating skipped checkpoints as neither pass nor failure - so a run
    # that verified a third of the deposit announced complete success. Coverage is now part
    # of the verdict: incomplete coverage is reported as incomplete, because a verifier that
    # overstates its own reach is the same failure as a gate trusted beyond its coverage.
    skipped = table[table['Restored'] & table['Predictions reproduced'].isna()]
    coverage = len(checked) / len(table) if len(table) else 0.0

    print(f'\n{len(table)} checkpoints: {len(checked)} predictions re-verified, '
          f'{len(skipped)} skipped (not verified), {len(unreadable)} unreadable, '
          f'{len(failures)} reproduced incorrectly, '
          f'{len(no_provenance)} without a recorded fingerprint')
    print(f'COVERAGE: {len(checked)}/{len(table)} ({coverage:.0%}) had predictions and '
          f'scores actually recomputed and compared.')
    if len(skipped):
        reasons = skipped['Error'].value_counts()
        for reason, count in reasons.items():
            print(f'  {count} skipped: {reason or "no reason recorded"}')
        print('  Restoration of a SKIPPED checkpoint rests on unpickling plus the presence '
              'of its fingerprint. Its predictions were NOT recomputed, so it is not '
              'evidence of restoration consistency.')

    hard_failure = len(failures) > 0 or len(unreadable) > 0
    status = 1 if (hard_failure or len(skipped) > 0) else 0
    if hard_failure:
        print('RESULT: VERIFICATION FAILED')
    elif len(skipped):
        print(f'RESULT: INCOMPLETE - every checkpoint examined passed, but only '
              f'{len(checked)} of {len(table)} were verified. Not a clean bill of health '
              f'for the deposit as a whole.')
    else:
        print(f'RESULT: all {len(table)} deposited models restored and reproduced their '
              f'recorded output')
    return status, table


if __name__ == '__main__':
    directory = sys.argv[1] if len(sys.argv) > 1 else 'p4_checkpoints_class_weight'
    code, frame = verify(directory)
    if len(frame):
        out = 'deposited_model_restoration.csv'
        frame.to_csv(out, index=False)
        print(f'wrote {out}')
    sys.exit(code)
