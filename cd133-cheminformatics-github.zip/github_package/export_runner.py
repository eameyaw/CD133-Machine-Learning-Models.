"""Export the Colab notebook to a headless runner script.

run_bench2.py was produced by hand, so the notebook and the script that actually generated
the results could drift apart without anyone noticing. This makes the export reproducible:
the notebook is the single source of truth and the runner is derived from it.

Skipped: the three Colab-only setup cells (pinned pip install, interactive file upload, the
run-configuration form). Their effect is supplied by the header below, which sets the run
flags explicitly so a runner can never silently inherit the wrong ones - the mistake that
cost a 45-minute re-run of the seven-descriptor path earlier in this project.
"""
import ast
import json
import os
import re
import sys

# Resolved relative to this file so the package works wherever it is cloned. Override
# with CD133_NOTEBOOK if the notebook is kept elsewhere.
NOTEBOOK = os.environ.get(
    'CD133_NOTEBOOK',
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 'CD133_Cheminformatics_Colab.ipynb'))
SKIP_LEADING_CELLS = 3

HEADER = """import matplotlib; matplotlib.use('Agg')
import os
RUN_FULL_BENCHMARK = {full}
RUN_APPENDIX = {appendix}
SHAP_BACKGROUND_N = {shap_n}
IMBALANCE_STRATEGY = {strategy!r}

# Extracted verbatim from the notebook's data-location cell, which is skipped here because
# it offers an interactive upload. Without it the execution manifest records NO dataset
# checksums on a headless run, silently defeating the dataset-integrity requirement. It is
# parsed from the notebook rather than restated, so the two cannot drift apart.
{data_files}
"""


def extract_data_files(cells):
    """Pull the DATA_FILES literal out of the skipped data-location cell."""
    for cell in cells:
        src = ''.join(cell['source']) if isinstance(cell['source'], list) else cell['source']
        match = re.search(r'^DATA_FILES = \{.*?^\}', src, re.S | re.M)
        if match:
            literal = match.group(0)
            # Must be a plain dict literal; evaluate it to confirm before emitting.
            parsed = ast.literal_eval(literal[len('DATA_FILES = '):])
            assert isinstance(parsed, dict) and parsed, 'DATA_FILES is not a non-empty dict'
            return literal, parsed
    raise SystemExit('DATA_FILES not found in the notebook; cannot guarantee checksums')


def undefined_name_gate(text, out_path):
    """Refuse to export source that references a name nothing defines.

    Two multi-hour runs of this project died on NameError - RESULTS_DIR used five cells
    before its definition, and confusion_matrix never imported in an appendix. Both were
    invisible to `compile`, which checks syntax and not name resolution, and both surfaced
    only after the expensive work had already completed. pyflakes resolves names
    statically, so this turns that class of failure into an export-time error.

    Names guarded by `if 'name' in globals():` are permitted: that idiom exists precisely
    to reference something which may legitimately be absent, and the guard makes the
    reference safe. Anything else fails the export.
    """
    try:
        from pyflakes.api import check
        from pyflakes.reporter import Reporter
    except ImportError:
        print('  WARNING: pyflakes is not installed, so the NameError gate did not run. '
              'Install it with `pip install pyflakes` before trusting an export.')
        return
    import io
    out, err = io.StringIO(), io.StringIO()
    check(text, out_path, Reporter(out, err))
    findings = [line for line in out.getvalue().splitlines() if 'undefined name' in line]
    offenders = {}
    for line in findings:
        match = re.search(r"undefined name '([^']+)'", line)
        if not match:
            continue
        name = match.group(1)
        # Permitted only if every reference is covered by an explicit presence guard.
        if f"'{name}' in globals()" in text:
            continue
        offenders.setdefault(name, []).append(line)
    if offenders:
        print(f'  NameError gate FAILED: {len(offenders)} unguarded undefined name(s)')
        for name, lines in sorted(offenders.items()):
            print(f'    {name}:')
            for line in lines[:3]:
                print(f'      {line.strip()}')
        raise SystemExit('refusing to export source that would raise NameError at runtime')
    guarded = len(findings) - sum(len(v) for v in offenders.values())
    print(f'  NameError gate passed ({guarded} guarded optional reference(s) allowed)')


def main(out_path, full=True, appendix=True, shap_n=500, strategy='class_weight'):
    with open(NOTEBOOK) as fh:
        nb = json.load(fh)
    all_cells = [c for c in nb['cells'] if c['cell_type'] == 'code']
    data_literal, data_parsed = extract_data_files(all_cells[:SKIP_LEADING_CELLS])
    cells = all_cells[SKIP_LEADING_CELLS:]

    chunks = [HEADER.format(full=full, appendix=appendix, shap_n=shap_n, strategy=strategy,
                            data_files=data_literal)]
    for i, cell in enumerate(cells, start=1):
        src = ''.join(cell['source']) if isinstance(cell['source'], list) else cell['source']
        bad = [ln for ln in src.splitlines()
               if ln.strip().startswith(('!', '%')) or 'files.upload(' in ln]
        if bad:
            sys.exit(f'cell {i} needs a notebook-only construct, refusing to export:\n  '
                     + '\n  '.join(bad[:3]))
        chunks.append(f'\n# ===================== CELL {i} =====================\n' + src.rstrip() + '\n')

    text = ''.join(chunks)
    compile(text, out_path, 'exec')          # syntax gate before anything is written
    undefined_name_gate(text, out_path)      # NameError gate, see below
    with open(out_path, 'w') as fh:
        fh.write(text)
    print(f'{out_path}: {len(cells)} cells, {len(text.splitlines())} lines')
    print(f'  RUN_FULL_BENCHMARK={full}  RUN_APPENDIX={appendix}  '
          f'SHAP_BACKGROUND_N={shap_n}  IMBALANCE_STRATEGY={strategy}')
    print(f'  DATA_FILES carried through: {sorted(data_parsed)}')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'run_bench3.py',
         strategy=sys.argv[2] if len(sys.argv) > 2 else 'class_weight')
