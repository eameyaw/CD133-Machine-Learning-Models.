"""Statistical consistency audit (author's safeguard 5).

The existing verifier checks that every number in the manuscript traces to an exported
file. That is necessary but not sufficient: a number can trace to a real export and still
be the WRONG export, or be correctly sourced but wrongly described. This audit covers what
tracing cannot.

Checks, each of which fails loudly rather than warning:

  A. Completeness      — all 48 combinations, 20 repetitions, 5 fold seeds actually present.
  B. Interval validity — the manuscript must quote the dependence-corrected intervals and
                         must NOT contain the naive ones, which overstate precision.
  C. Rank stability    — the SVM scoring-route change can only alter the benchmark ordering
                         if two models sit within the measured ROC-AUC difference of each
                         other. Verified rather than argued.
  D. Score disclosure  — every SVM row must be labelled as scored by decision function.
  E. Claim language    — the repeated analysis must not be called external validation or
                         unbiased; SHAP must not be given causal or mechanistic phrasing.
  F. Partition hygiene — the previously exposed partition must be absent from the primary
                         estimate, and all repetition partitions must be distinct.

Usage:  python3 audit_consistency.py [results_dir] [manuscript.txt]

Exit status is non-zero if any check fails, so it can gate the manuscript revision.
"""
import json
import os
import re
import sys

import pandas as pd

FAILURES = []
PASSES = []


def check(name, condition, detail=''):
    (PASSES if condition else FAILURES).append((name, detail))
    print(f'{"PASS" if condition else "FAIL"}  {name}' + (f'\n      {detail}' if detail else ''))


def load(results_dir, name, required=True):
    path = os.path.join(results_dir, name)
    if not os.path.exists(path):
        if required:
            FAILURES.append((f'missing export: {name}', ''))
            print(f'FAIL  missing export: {name}')
        return None
    return pd.read_csv(path) if name.endswith('.csv') else json.load(open(path))


def audit(results_dir='results_export', manuscript_text=None):
    print(f'=== statistical consistency audit: {results_dir} ===\n')

    # ---- A. completeness ---------------------------------------------------------------
    oof = load(results_dir, 'benchmark_out_of_fold.csv')
    if oof is not None:
        check('A1 all 48 benchmark combinations present', len(oof) == 48,
              f'{len(oof)} rows')
        check('A2 both splitting strategies present',
              oof['Splitting strategy'].nunique() == 2 if 'Splitting strategy' in oof else False,
              f'strategies: {sorted(oof["Splitting strategy"].unique()) if "Splitting strategy" in oof else "column absent"}')
        check('A3 three representations present',
              oof['Representation'].nunique() == 3 if 'Representation' in oof else False,
              f'{sorted(oof["Representation"].unique()) if "Representation" in oof else "column absent"}')

    rep = load(results_dir, 'appendix_seed_stability.csv')
    if rep is not None:
        check('A4 twenty repetitions completed', len(rep) == 20, f'{len(rep)} repetitions')

    manifest = load(results_dir, 'execution_manifest.json', required=False)
    if manifest:
        a2 = manifest.get('execution', {}).get('repeated internal validation (A2)', {})
        check('A5 manifest configured count equals completed count',
              a2.get('repetitions configured') == a2.get('repetitions completed'),
              f'configured {a2.get("repetitions configured")}, '
              f'completed {a2.get("repetitions completed")}')
        a11 = manifest.get('execution', {}).get('imbalance selection (A11)', {})
        check('A6 five fold seeds in the selection analysis',
              a11.get('fold seeds configured') == 5,
              f'{a11.get("fold seeds configured")} configured, '
              f'{a11.get("repeats completed")} completed')
        check('A7 checkpoint restoration failures recorded explicitly',
              'checkpoint restoration failures' in manifest.get('execution', {}),
              f'{manifest["execution"].get("checkpoint restoration failures")} failures')

    # ---- B. interval validity ----------------------------------------------------------
    # The corrected interval is wider than the naive one; if the manuscript contains the
    # naive bounds, an independence assumption has leaked into the write-up.
    if rep is not None and 'ROC-AUC' in rep.columns and len(rep) > 1:
        import numpy as np
        sd = float(rep['ROC-AUC'].std(ddof=1))
        n = len(rep)
        overlap = 0.2 / 0.8
        naive = 1.96 * sd / np.sqrt(n)
        corrected = 1.96 * sd * np.sqrt(1.0 / n + overlap)
        check('B1 corrected interval is wider than the naive interval',
              corrected > naive,
              f'naive +/-{naive:.4f}, corrected +/-{corrected:.4f} '
              f'({corrected / naive:.2f}x)')
        if manuscript_text:
            mean = float(rep['ROC-AUC'].mean())
            naive_bounds = {f'{mean - naive:.3f}', f'{mean + naive:.3f}'}
            present = sorted(b for b in naive_bounds if b in manuscript_text)
            check('B2 manuscript does not quote the naive interval bounds',
                  not present, f'naive bounds found in text: {present}' if present
                  else 'no naive bounds present')

    # ---- C. rank stability under the scoring-route change ------------------------------
    route = load(results_dir, 'svm_scoring_route_summary.json', required=False)
    if route and oof is not None and 'ROC-AUC' in oof.columns:
        delta = abs(float(route.get('ROC-AUC difference (decision - Platt)', 0.0)))
        # Only pairs INVOLVING the support vector machine can be reordered by the scoring
        # route, because only the SVM's score changed. The earlier version compared the
        # route difference against every adjacent pair and so failed on a Logistic
        # Regression vs Elastic Net pair that the route cannot touch - a false failure that
        # obscured the real question. The genuine closeness of unrelated pairs is a separate
        # finding, checked as C3 below.
        for strategy, group in (oof.groupby('Splitting strategy')
                                if 'Splitting strategy' in oof else []):
            for representation, sub in group.groupby('Representation'):
                ranked = sub.sort_values('ROC-AUC').reset_index(drop=True)
                svm_gaps = []
                for i in range(len(ranked) - 1):
                    pair = (ranked['Model'][i], ranked['Model'][i + 1])
                    if any('Support Vector' in str(m) for m in pair):
                        svm_gaps.append((pair,
                                         ranked['ROC-AUC'][i + 1] - ranked['ROC-AUC'][i]))
                if not svm_gaps:
                    continue
                worst_pair, smallest = min(svm_gaps, key=lambda t: t[1])
                check(f'C1 SVM ranking stable under the scoring route '
                      f'({strategy}/{representation})', smallest > delta,
                      f'closest SVM-adjacent pair {worst_pair[0]} vs {worst_pair[1]}: '
                      f'gap {smallest:.6f} = {smallest / delta:.1f}x the measured route '
                      f'difference {delta:.2e}')
        check('C2 route difference recorded as non-identical',
              route.get('Identical ranking') is False,
              f'Identical ranking = {route.get("Identical ranking")}, '
              f'Spearman = {route.get("Spearman rank correlation of scores")}')

    # ---- C3. is the benchmark ordering resolvable at all? ------------------------------
    # The substantive question the old C1 was accidentally gesturing at. A difference
    # smaller than the uncertainty interval does not establish an ordering, so a table
    # presented as a ranking would overstate what the benchmark shows.
    if oof is not None and rep is not None and 'ROC-AUC' in oof.columns and len(rep) > 1:
        import numpy as np
        sd = float(rep['ROC-AUC'].std(ddof=1))
        half = 1.96 * sd * np.sqrt(1.0 / len(rep) + 0.2 / 0.8)
        total = unresolved = 0
        for _, sub in oof.groupby(['Splitting strategy', 'Representation']):
            values = sub['ROC-AUC'].sort_values(ascending=False).to_numpy()
            gaps = [values[i] - values[i + 1] for i in range(len(values) - 1)]
            total += len(gaps)
            unresolved += sum(1 for g in gaps if g < half)
        best = float(oof['ROC-AUC'].max())
        tied_with_best = int((oof['ROC-AUC'] >= best - half).sum())
        # Informational, and it passes: the finding is not a defect, it is a constraint on
        # how the tables may be described. The language check below is what enforces that.
        check('C3 benchmark ordering resolvability measured', True,
              f'{unresolved} of {total} adjacent pairs are closer than the corrected '
              f'interval (+/-{half:.4f}); {tied_with_best} of {len(oof)} combinations are '
              f'indistinguishable from the best. Tables must be presented as grouped, '
              f'not ranked.')
        if manuscript_text:
            lowered_ms = manuscript_text.lower()
            ranking_words = sum(lowered_ms.count(w) for w in
                                ('best-performing model', 'outperformed', 'ranked first',
                                 'superior to', 'the top model'))
            qualified = any(p in lowered_ms for p in
                            ('not resolvable', 'indistinguishable', 'within the interval',
                             'cannot be ordered', 'statistically indistinguishable'))
            check('C4 unresolvable ordering is qualified in the text',
                  ranking_words == 0 or qualified,
                  f'{ranking_words} ranking phrase(s) present; qualification present: '
                  f'{qualified}')

    # ---- D. score-type disclosure ------------------------------------------------------
    if oof is not None and 'Score type' in oof.columns:
        svm = oof[oof['Model'].str.contains('Support Vector', na=False)]
        check('D1 every SVM row labelled as scored by decision function',
              len(svm) > 0 and (svm['Score type'] == 'decision function').all(),
              f'{len(svm)} SVM rows, types: {sorted(svm["Score type"].unique())}')
        others = oof[~oof['Model'].str.contains('Support Vector', na=False)]
        check('D2 non-SVM rows labelled as probability',
              (others['Score type'] == 'probability').all(),
              f'types: {sorted(others["Score type"].unique())}')

    # ---- E. claim language -------------------------------------------------------------
    if manuscript_text:
        lowered = manuscript_text.lower()
        forbidden = [
            ('external validation', 'the repeated analysis is internal, not external'),
            ('unbiased independent', 'the estimate is not unbiased independent test performance'),
            ('proof of generalization', 'no generalization proof is supported'),
            ('proves generalization', 'no generalization proof is supported'),
        ]
        for phrase, why in forbidden:
            hits = lowered.count(phrase)
            # 'external validation' may legitimately appear while DISCLAIMING it.
            disclaimed = bool(re.search(
                r'(not|rather than|is no[t]?)\s+(an?\s+)?(independent\s+)?' + re.escape(phrase),
                lowered))
            check(f'E1 "{phrase}" not claimed', hits == 0 or disclaimed,
                  f'{hits} occurrence(s); disclaimed={disclaimed}; {why}')
        causal = re.findall(
            r'(?:shap|shapley)[^.]{0,120}?\b(causes?|causal|mechanis\w+|drives?|'
            r'responsible for|determines?)\b', lowered)
        check('E2 SHAP given no causal or mechanistic phrasing', not causal,
              f'found: {causal[:4]}' if causal else 'none')
        check('E3 repeated analysis described as internal validation',
              'internal validation' in lowered or 'internal-validation' in lowered,
              'phrase present' if 'internal valid' in lowered else 'phrase ABSENT')

    # ---- F. partition hygiene ----------------------------------------------------------
    if rep is not None:
        if 'Seed' in rep.columns:
            check('F1 previously exposed partition (seed 101) excluded',
                  101 not in set(rep['Seed'].tolist()),
                  f'seeds: {sorted(rep["Seed"].tolist())}')
        if 'Test index sha256' in rep.columns:
            check('F2 all repetition partitions distinct',
                  rep['Test index sha256'].nunique() == len(rep),
                  f'{rep["Test index sha256"].nunique()} distinct of {len(rep)}')

    print(f'\n{len(PASSES)} passed, {len(FAILURES)} failed')
    if FAILURES:
        print('FAILED CHECKS:')
        for name, detail in FAILURES:
            print(f'  - {name} {detail}')
    print('RESULT:', 'consistent' if not FAILURES else 'AUDIT FAILED')
    return 1 if FAILURES else 0


if __name__ == '__main__':
    directory = sys.argv[1] if len(sys.argv) > 1 else 'results_export'
    text = None
    if len(sys.argv) > 2 and os.path.exists(sys.argv[2]):
        text = open(sys.argv[2], encoding='utf-8', errors='replace').read()
        print(f'manuscript text: {sys.argv[2]} ({len(text)} chars)\n')
    sys.exit(audit(directory, text))
