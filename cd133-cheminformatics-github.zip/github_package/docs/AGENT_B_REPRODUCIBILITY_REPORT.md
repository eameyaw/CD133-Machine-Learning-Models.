# Agent B — independent reproducibility audit

Independent verification of the CD133 cheminformatics ML benchmark. Agent B did not produce
this work. Nothing in the analysis (code, notebook, checkpoints, exported results) was
modified; all verification ran from a separate scratch directory. No tolerance in
`REPRODUCIBILITY_TOLERANCES.md` was altered, and no tolerance was derived after seeing a
result.

Audit date: 2026-10-28.

## Software environment

The prespecified tolerances are only valid in the environment they were derived from.
`results_export/software_environment.json` records, and this audit ran in:

| Component | Version |
|---|---|
| Python | 3.13.18 |
| scikit-learn | 1.9.1 |
| imbalanced-learn | 0.14.2 |
| xgboost | 3.4.1 |
| numpy | 2.5.3 |
| pandas | 3.0.5 |
| joblib | 1.6.0 |
| shap | 0.54.1 |
| rdkit | 2026.09.1 |

Imbalance strategy `class_weight`; estimator module `cd133_estimators.py`; estimators fitted
unweighted: `KNeighborsClassifier`. `results_export/execution_manifest.json` additionally
records matplotlib 3.11.2. The two environment records agree on every shared key.

Both findings below were obtained in this environment only. They do not transfer to another
platform, library version or thread count.

---

# FINDING 1 — Artifact restoration consistency

**Claim tested.** A deposited checkpoint, loaded in a fresh process that defines no estimator
class of its own, reproduces the predictions and ranking scores stored inside it.

**Method.** `python3 verify_deposited_models.py p4_checkpoints_class_weight`, run unmodified
against `/home/claude/clean_run/p4_checkpoints_class_weight` (48 checkpoints). Output written
to `deposited_model_restoration.csv`.

**Tolerance applied and its source.** The verifier's own criteria: label predictions exact
(`np.array_equal`), ranking scores `rtol = atol = 1e-12` (`np.allclose`). This is tighter than
every per-estimator restoration bound in `REPRODUCIBILITY_TOLERANCES.md` except the "exact"
rows, so passing the verifier implies passing the prespecified table. Bit-exactness is
recorded separately rather than required — consistent with defect 6 in the register.

**I reviewed the verifier before trusting it. Its prediction/score criteria are sound.** One
criterion is not: see the restoration-coverage limitation below.

## Results

48 of 48 checkpoints restored. 48 of 48 carried a recorded fingerprint. 0 unreadable,
0 reproduced incorrectly. The verifier exited 0.

**16 of 48 had their predictions and scores actually re-verified.** The other 32 were
reported `SKIP` — "fingerprint-only verification" — because the verifier reads
`curated_descriptors.csv` (7 features) and those checkpoints expect 1024 (ECFP4) or 1031
(Hybrid) features. For those 32, restoration was demonstrated only as *successful unpickling
plus fingerprint presence*, not as reproduction of recorded output. The script's own docstring
states that a successful import does not demonstrate restoration, so this is a gap in its
coverage, not in its reasoning.

All 16 verified checkpoints reproduced label predictions **exactly** (681/681 rows each, both
splits).

Observed maximum ranking-score deviation, per estimator family (the maximum across the Random
and Scaffold 7-descriptor checkpoints), against the prespecified restoration bound:

| Estimator | Observed max deviation | Prespecified bound | Margin | Bit-exact |
|---|---|---|---|---|
| Gini decision tree | 0.0 | exact | met exactly | **yes** |
| Entropy decision tree | 0.0 | exact | met exactly | **yes** |
| k-nearest neighbours | 0.0 | exact | met exactly | **yes** |
| Random Forest | 0.0 | 1e-12 | bound not approached | **yes** |
| XGBoost | 0.0 | 1e-10 | bound not approached | **yes** |
| Logistic regression | 7.77e-16 | 1e-12 | ~1,300x inside | no |
| Elastic net LR | 6.66e-16 | 1e-12 | ~1,500x inside | no |
| Support vector machine | 1.71e-13 | 1e-10 | ~585x inside | no |

Per-checkpoint values (Random / Scaffold): elastic net 5.55e-16 / 6.66e-16; logistic
regression 2.22e-16 / 7.77e-16; SVM 1.16e-13 / 1.71e-13; all five tree- and
distance-based estimators 0.0 / 0.0.

**Bit-exact estimators:** both decision trees, k-nearest neighbours, Random Forest and
XGBoost — 10 of the 16 verified checkpoints, deviation identically 0.0. The three linear/kernel
families were not bit-exact, as the tolerance document anticipated. The SVM is the closest to
its bound and still clears it by more than two orders of magnitude; nothing passed by a hair.

**FINDING 1 VERDICT: PASS, with reduced coverage.** All 48 deposited checkpoints load in a
fresh process with provenance recorded. For the 16 seven-descriptor checkpoints, predictions
are exact and scores are within the prespecified bounds by two to three orders of magnitude.
For the 32 fingerprint-only checkpoints the claim is **not** established.

**What Finding 1 does not establish.** It says nothing about whether the pipeline can be
retrained to the same numbers (that is Finding 2), nothing about the 32 skipped checkpoints'
numerical output, and nothing about behaviour in any other software environment.

---

# FINDING 2 — Independent refit reproducibility

**Claim tested.** A model retrained from the documented data, code, dependencies and seeds
reproduces the stored predictions and metrics. This is strictly stronger than Finding 1, and
Finding 1 passing provides no evidence for it.

**Scope — deliberately limited, and stated as such.** Refitting all 48 combinations would take
hours. I refit **4 of 48 combinations**, all on the **Random** split with the **7 Lipinski
descriptors** representation:

- Random Forest (the designated model)
- Gini Decision Tree
- Logistic Regression
- Support Vector Machine (scored by `decision_function`, not `predict_proba`)

**Method.** I read `run_production.py` and reproduced its construction rather than importing
it: `p4_pipeline` under `IMBALANCE_STRATEGY='class_weight'`
(`StandardScaler` → `class_weight='balanced'` estimator, no resampler); the per-model grids as
written in the notebook cells; `StratifiedKFold(n_splits=5, shuffle=True, random_state=42)`
for the final-search inner folds, built from the Random training partition exactly as
`p4_make_folds` does; `RandomForestClassifier(n_estimators=500, random_state=42, n_jobs=1)`;
`GridSearchCV(..., scoring='roc_auc', n_jobs=-1)`. Inputs: `curated_descriptors.csv`,
`curated_labels.csv`, `curated_train_rows.csv`, `curated_test_rows.csv` (3,401 compounds;
2,720 train / 681 held out; 7 features). I asserted the row files agree cell-for-cell with the
descriptor table, and that train and test indices are disjoint and exhaustive.

Each refit's fresh held-out predictions and ranking scores were compared against the
`held_out` frame stored inside the corresponding checkpoint.

**Independent confirmation that I used the right data.** For each model I recomputed the
checkpoint fingerprint (SHA-256 over train rows, test rows, labels, feature count, estimator
`repr` and imbalance strategy) from my own inputs and templates. **All four matched the stored
fingerprint**, which confirms the curated inputs, partition, labels and estimator
configuration I refit from are the ones the checkpoint was produced from. The selected
hyperparameters also matched in all four cases.

**Tolerances applied and their source.** Taken verbatim from
`REPRODUCIBILITY_TOLERANCES.md` — ranking score: decision tree exact (demonstrated); Random
Forest `atol=1e-12`; logistic regression `atol=1e-12`; SVM `atol=1e-10`. Label predictions:
exact, all models. Aggregate metrics: `atol=1e-6`, the document's explicit independent-refit
bound.

## Results

| Model | Max ranking-score deviation | Score tolerance | Labels exact | Max metric deviation | Metric tolerance | Verdict |
|---|---|---|---|---|---|---|
| **Random Forest** | **0.0 (bit-exact)** | 1e-12 | yes (0/681 differ) | **0.0** | 1e-6 | **PASS** |
| Gini Decision Tree | **0.0 (bit-exact)** | exact | yes (0/681 differ) | **0.0** | 1e-6 | **PASS** |
| Logistic Regression | 5.55e-16 | 1e-12 | yes (0/681 differ) | **0.0** | 1e-6 | **PASS** |
| Support Vector Machine | 1.22e-13 | 1e-10 | yes (0/681 differ) | **0.0** | 1e-6 | **PASS** |

Selected hyperparameters, stored vs refitted (all MATCH): Random Forest
`max_depth=12, max_features='sqrt', min_samples_leaf=1`; Gini tree
`max_depth=6, min_samples_leaf=20`; SVM `C=1, kernel='rbf'`; Logistic Regression untuned.

All eight aggregate metrics (accuracy, active-class precision / recall / F1, specificity,
balanced accuracy, ROC-AUC, PR-AUC) reproduced at **deviation exactly 0.0** for all four
models — not merely within 1e-6. The refit metrics also match the published
`results_export/benchmark_held_out.csv` rows digit for digit, e.g. Random Forest ROC-AUC
0.8461475693 and PR-AUC 0.7401336245.

Margins: the Random Forest and the Gini tree cleared their bounds completely (identically
zero). Logistic regression cleared `1e-12` by roughly 1,800x and the SVM cleared `1e-10` by
roughly 820x. No model passed narrowly.

Notably, the Random Forest refit was **bit-exact** even though the tolerance document
deliberately declines to assert exactness for it. That is a stronger result than was claimed,
observed on one combination in one environment; it is evidence for the forest's determinism
here, not a basis for asserting exactness generally, and the document's refusal to claim it
remains the correct position.

**FINDING 2 VERDICT: PASS for the four combinations tested.** Retraining from the documented
data, code and seeds reproduced the stored held-out predictions exactly and the stored metrics
to deviation 0.0, within the prespecified tolerances with large margins.

**Models and configurations I did NOT test, and to which this finding does not extend:**
Elastic Net-Regularized Logistic Regression, Entropy-Based Decision Tree, K-Nearest Neighbors,
XGBoost (all 4 on Random / 7 descriptors), and **all 40 combinations** on the ECFP4
representation, the Hybrid representation, or the Scaffold split. Finding 2 covers 4 of 48
combinations. It makes no statement about the other 44. In particular, XGBoost is the
estimator the tolerance document flags as most exposed to order-dependent summation and it was
not refit; and the custom `P4FoldBalancedXGBClassifier` refit path was not exercised.

---

# Additional verifications

## Configuration completeness — PASS

`benchmark_out_of_fold.csv` and `benchmark_held_out.csv` each: exactly **48 rows**; **0**
duplicate `(Splitting strategy, Representation, Model)` combinations; **2** strategies
(Random, Scaffold); **3** representations (7 Lipinski descriptors, ECFP4, Hybrid); **8**
models. 2 x 3 x 8 = 48, fully crossed with no gaps. Every row records
`Imbalance strategy = class_weight`.

## Score-type disclosure — PASS

In both frames, all 6 Support Vector Machine rows are labelled `decision function` and all 42
non-SVM rows are labelled `probability`. No mixed or missing labels.

## Execution provenance — PASS, with one caveat

`production.log` contains boundary records for both chunks:

- `CHUNK 1 START 2026-10-28T17:58:29Z resume=0 checkpoints_before=0`
- `CHUNK 1 END 2026-10-28T19:59:07Z python_exit_status=KILLED_AT_BACKGROUND_TIME_LIMIT checkpoints_after=48`
- `=== CHUNK START 2026-10-28T19:59:10Z resume=1 checkpoints_before=48 ===`
- `=== CHUNK END 2026-10-28T20:36:38Z python_exit_status=0 checkpoints_after=48 ===`

Chunk 1 stopped at the time limit; chunk 2 exited 0. The manifest independently records
`status: completed`, 48 combinations, duration 2245.3 s, A2 20/20 repetitions with 20 distinct
partition checksums, A11 5/5 repeats.

**Caveat, stated because it bears on the strength of the provenance claim.** The log itself
discloses that the chunk 1 record was "transcribed from the harness task output" rather than
written by the launcher into the log. So chunk 1's `KILLED_AT_BACKGROUND_TIME_LIMIT` is a
transcribed assertion, not a machine-captured status I could verify from the artifact. Chunk
2's `exit_status=0` is machine-written in the log. Given defect 12 in the register (exit status
masked by the launch command), the distinction is worth naming; it does not contradict
anything, and chunk 1's claim that all 48 checkpoints completed is independently corroborated
by Finding 1 (48 of 48 load with valid fingerprints).

The manifest also records `"checkpoints reused from a previous run": true`, so the chunk-2
benchmark tables were produced from checkpoints written during chunk 1 rather than refitted.
That is the documented intent, and Finding 2 is the independent check that those reused
artifacts are reproducible.

## Checkpoint restoration failures — PASS

`results_export/checkpoint_restoration_failures.csv` **exists** and records **0 failures** (a
header row only, no data rows). Per defect 13 this is a positive statement, not an absent
file. The manifest agrees: `"checkpoint restoration failures": 0` and an empty
`checkpoint restoration detail` list.

## `audit_consistency.py results_export` — 18 passed, 1 FAILED (exit 1)

Passing: A1 (48 combinations), A2 (2 strategies), A3 (3 representations), A4 (20 repetitions),
A5 (configured = completed), A6 (5 fold seeds), A7 (0 restoration failures recorded
explicitly), B1 (corrected interval wider than naive: +/-0.0146 vs +/-0.0060, 2.45x), C1 for
5 of 6 strategy x representation cells, C2 (route difference recorded as non-identical,
Spearman 0.99965), D1 (6 SVM rows all `decision function`), D2 (all non-SVM `probability`),
F1 (seed 101 excluded), F2 (20 of 20 partitions distinct).

**Not applicable — require manuscript text, which does not exist yet:** B2 (manuscript must
not quote the naive interval bounds), E1 (forbidden claim phrases: "external validation",
"unbiased independent", "proof of generalization", "proves generalization"), E2 (SHAP given no
causal phrasing), E3 (repeated analysis described as internal validation). The script gates
these on a second argument and skips them silently when it is absent; they are untested, not
passed.

### The one failure, reported prominently

```
FAIL  C1 ranking stable under the scoring route (Scaffold/7 Lipinski descriptors)
      smallest gap between adjacent models 0.000016 vs measured route difference 8.01e-05
```

I investigated rather than reporting a bare verdict.

**What the check does.** It takes the measured SVM scoring-route difference
(decision_function minus Platt, 8.01e-05 ROC-AUC, from `svm_scoring_route_summary.json`) and
requires that the smallest gap between *any* two adjacent models in the out-of-fold ROC-AUC
ranking exceed it.

**Which pair triggers it.** In Scaffold / 7 Lipinski descriptors the failing gap is
**Logistic Regression (0.811988) vs Elastic Net-Regularized Logistic Regression (0.811971),
a gap of 1.63e-05**. Neither is the Support Vector Machine.

**My assessment — two separate points, and both belong in the record.**

1. *The check as coded is over-broad.* The scoring-route change moves only the SVM's score, so
   it cannot perturb the gap between two logistic regression variants. Applying an
   SVM-specific perturbation to every adjacent pair is a mis-specification. On the substantive
   question the check exists to answer — is the SVM's rank position stable under its scoring
   route — the answer is yes in all six cells: the smallest SVM-adjacent gap is 1.283e-03
   (Random/7 descriptors) and 1.160e-03 (Scaffold/7 descriptors), i.e. **14.5x to 206x the
   route difference**. I did not change the check or the tolerance; I am reporting the
   observed numbers alongside the failure.

2. *A real finding the failure surfaces, independent of point 1.* Logistic Regression and
   Elastic Net-Regularized Logistic Regression are separated by **1.63e-05 ROC-AUC
   out-of-fold and 9e-06 held-out** in Scaffold / 7 Lipinski descriptors. That is far below any
   resolution this study can support — smaller than the SVM route artefact and vastly smaller
   than the dependence-corrected interval half-width of +/-0.0146. **Any manuscript statement
   ordering these two models in this cell is unsupportable** and should report them as tied.
   This is a presentation constraint, not a computational defect.

The audit exits non-zero. I am not recommending the check be loosened to clear it; the
defensible fixes are to make C1 compare the route delta only against SVM-adjacent gaps, or to
leave the check failing as a standing reminder of point 2. That is the authors' call, not mine.

---

# Limitations — what I could not verify, and why

1. **Finding 2 covers 4 of 48 combinations** (Random split, 7 Lipinski descriptors). Refitting
   all 48 would take hours. 44 combinations are unverified for refit reproducibility,
   including every ECFP4 and Hybrid model, every Scaffold-split model, and XGBoost — the
   estimator most exposed to order-dependent summation and the one whose custom
   `P4FoldBalancedXGBClassifier` refit path was therefore never exercised.

2. **Finding 1 fully verified 16 of 48 checkpoints.** The 32 ECFP4 and Hybrid checkpoints were
   skipped by the verifier because the deposited descriptor file has 7 features and they
   expect 1024 or 1031. Their restoration rests on successful unpickling and fingerprint
   presence only. The script still printed "all deposited models restored and reproduced their
   recorded output" and exited 0, because its status logic counts skips as neither pass nor
   failure. **That summary line overstates what was tested** and the fingerprint-only
   checkpoints should be named in any claim derived from it. Closing the gap requires
   depositing the ECFP4 and Hybrid feature matrices, or regenerating them from SMILES, neither
   of which is available in this directory.

3. **Curated inputs are absent from the deposition directory.** `curated_descriptors.csv`,
   `curated_labels.csv`, `curated_train_rows.csv` and `curated_test_rows.csv` do not exist in
   `/home/claude/clean_run`; I sourced them from `/home/claude/colabtest`. Consequently the
   manifest's `datasets -> curated derivatives` block is **empty**: the manifest names
   `curated_train_rows.csv` as the deposited partition index file but records **no checksum**
   for it, because the exporter only hashes those files when they are present in the working
   directory. A third party downloading this directory alone could not run either finding.
   I mitigated this by recomputing each checkpoint's fingerprint from the inputs I used; all
   four matched, which establishes that the `colabtest` curated files are the exact data behind
   the `clean_run` checkpoints. That is a strong substitute but it is not a deposited checksum,
   and it only covers the 7-descriptor Random combinations I refit.

4. **Checkpoint binaries differ between directories.** The `clean_run` and `colabtest`
   checkpoint files are not byte-identical (differing MD5 on the Random/7-descriptor Random
   Forest), as expected for independently serialised runs. I verified the `clean_run`
   checkpoints only. The `colabtest` set, and the `p4_checkpoints_pre_round5` and
   `p4_checkpoints_stale_smote_prefix` directories there, were not audited.

5. **Single environment, single machine, single run.** Every deviation reported here was
   measured once, in the environment tabulated above. The tolerance document's own scope note
   applies: these numbers do not transfer to another platform, library version, thread count or
   hardware, and I did not vary any of them. In particular I did not test whether the
   bit-exactness observed for the Random Forest survives a different `n_jobs` or BLAS thread
   count — which is precisely why the document declines to assert it.

6. **Out-of-fold predictions were not refit.** Finding 2 compares the held-out frame only. The
   nested out-of-fold loop (5 outer x 5 inner searches per combination) was out of scope for
   the time budget, so `benchmark_out_of_fold.csv` is unverified by refit. Its configuration
   completeness and score-type disclosure were checked.

7. **Manuscript-dependent checks are untested, not passed.** B2, E1, E2 and E3 in
   `audit_consistency.py` require manuscript text that does not yet exist. They must be re-run
   once a draft exists; nothing in this report speaks to the claim language of the eventual
   manuscript.

8. **I verified reproducibility, not scientific validity.** That stored and refit numbers agree
   says nothing about whether the splits, the imbalance handling, the metric choices or the
   defect-register corrections are scientifically appropriate. I audited the corrections'
   *consequences* where an exported artifact let me (seed 101 excluded, intervals widened,
   score types disclosed, restoration failures recorded); I did not re-derive the decisions
   behind them. I also did not independently re-curate the dataset from the raw assay file,
   so the curation step upstream of `curated_descriptors.csv` is outside this audit.
