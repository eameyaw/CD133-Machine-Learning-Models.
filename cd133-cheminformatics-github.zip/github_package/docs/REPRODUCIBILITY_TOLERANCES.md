# Prespecified reproducibility tolerances

Fixed **before** the verification runs, so a tolerance cannot be chosen to fit a result.
Required by the author's condition 5: model-specific, justified, with exact equality claimed
only where it has actually been demonstrated.

## Two findings, reported separately

These are different claims and a pass on the first says nothing about the second.

**Finding 1 — Artifact restoration consistency.** A deposited checkpoint, loaded in a fresh
process, reproduces the predictions and ranking scores stored alongside it. This tests the
stored artifact, in this environment.

**Finding 2 — Independent refit reproducibility.** A model retrained from the documented
data, code, dependencies and seeds reproduces the expected predictions and metrics. This
tests the *pipeline*, and is the stronger claim.

## Tolerances

| Estimator | Label predictions | Ranking score | Basis |
|---|---|---|---|
| Gini / Entropy decision tree | exact | exact (demonstrated) | Single tree, no reduction over threads; measured 0.0 deviation on restoration |
| k-nearest neighbours | exact | exact (demonstrated) | Distance ranking, no floating reduction; measured 0.0 |
| Random Forest | exact | `atol=1e-12` | Measured 0.0 on restoration, but the forest sums 500 tree votes and `n_jobs` affects the order, so exactness is NOT asserted for a refit |
| XGBoost | exact | `atol=1e-10` | Histogram construction and multithreaded gradient sums are order-dependent; a looser bound than the forest is deliberate |
| Logistic regression | exact | `atol=1e-12` | BLAS reduction order varies with thread count; measured 2.2e-16 |
| Elastic net | exact | `atol=1e-12` | As above; measured 5.6e-16. Iterative solver, so a refit may also differ by convergence path |
| Support vector machine | exact | `atol=1e-10` | Measured 1.2e-13 on restoration; kernel sums over support vectors are order-dependent and the solver is iterative |

Aggregate metrics (ROC-AUC, PR-AUC, precision, recall, F1, specificity, balanced accuracy):
`atol=1e-9` for restoration, `atol=1e-6` for an independent refit. The looser refit bound
reflects that a single reordered near-tie can move a rank-based metric by more than the
score deviation itself.

## What is NOT claimed

Exact equality is asserted only for the decision trees and k-nearest neighbours, and only
for restoration in this environment, where it was measured at 0.0. It is **not** asserted
for Random Forest or XGBoost despite their fixed `random_state`: parallel reductions,
library version, thread count and hardware can all change summation order. An earlier
statement in this project that a fixed seed implies bit-identical refits for tree models was
wrong, and these tolerances replace it.

Nothing here licenses widening a tolerance after seeing a result. A deviation above the
bound is a finding to investigate and report, not a number to accommodate.

## Scope of these tolerances

The deviations behind these bounds (2e-16 to 1.2e-13) were measured on **specific
quantities** — held-out ranking scores from the seven-descriptor random-split checkpoints —
in **one environment**, recorded in `software_environment.json`. They are not universal
constants for every estimator, representation, platform or metric.

So the bounds above apply to the quantity and environment they were derived from. For any
other quantity, representation or environment, the tolerance must be derived there and
stated, not inherited from this table.

Agent B reports, for each of its two findings separately:
- the exact quantities tested (which models, which representations, which outputs);
- the tolerance applied to each, and where that tolerance came from;
- the software environment the test ran in;
- pass or fail per quantity, with observed deviations, not just a verdict.

A verdict without the observed deviation is not a usable finding: it hides whether a pass
cleared its bound by orders of magnitude or by a hair.
