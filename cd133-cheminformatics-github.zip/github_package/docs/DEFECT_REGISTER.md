# Defect register — round 5 implementation corrections

Every defect found while implementing the author's round-5 decisions, with its root cause,
the correction, and the evidence that the correction works.

Scope note on honesty of attribution: I previously reported "nine defects found by
execution". That count was wrong in two ways. The true total is **seventeen**, and ten
of those were found by execution — the rest were found by static inspection, by
testing a component in isolation, or by the author challenging a claim. Each row below
states which, because "found by running it" and "found by someone questioning it" are
different kinds of evidence and collapsing them overstates how much the test suite caught.

Severity key:
- **Blocking** — would have aborted a run, destroying hours of compute.
- **Silent-wrong** — would have completed and produced incorrect or mislabelled numbers.
- **Integrity** — would have weakened reproducibility or provenance without affecting numbers.
- **Noise** — correct results, unusable output.

---

## Silent-wrong defects

These are the dangerous ones: the analysis completes, and the output is wrong or mislabelled.

### 1. Repeated-splits hyperparameters tuned once, outside the repetition
**Severity** Silent-wrong · **Found by** code review against the author's condition 3

The repeated-splits analysis (A2) tuned the forest once on the original training partition
and reused those hyperparameters across all fresh splits. Each fresh split draws its test
rows from the whole curated set, so those rows overlap the partition the hyperparameters
came from — the configuration being scored had already seen them.

**Why it mattered** This analysis was being promoted to the *primary* performance estimate.
A leak there contaminates the headline number, and the output was described as split-to-split
variability of a model that had in fact seen the data.

**Correction** The grid search now runs inside each repetition's training partition only,
using the designated template so the search space is fixed in advance rather than restated.

**Evidence** A per-repetition assertion confirms the scaler saw exactly that repetition's
training rows. Execution shows the search selecting **two distinct hyperparameter settings**
across repetitions, which is only possible because tuning is now inside the loop.

### 2. Previously exposed partition included in the headline estimate
**Severity** Silent-wrong · **Found by** execution (a metric matched too exactly)

A2's first repetition used seed 101 and returned ROC-AUC 0.8461 — identical to the reported
held-out figure. Seed 101 reproduces the deposited partition exactly, and that partition had
been examined during the exploratory SMOTE-versus-class-weighting comparison.

**Why it mattered** Previously exposed data was sitting inside the estimate that exists
specifically to avoid it, as 1 of 20 repetitions.

**Correction** Seed 101 excluded by assertion, replaced with a fresh seed. The partition is
reported only as the supplementary, previously exposed result.

**Evidence** Verified by index-set equality — `set(test_index) == set(deposited_test_rows)`
returns `True` — not inferred from the matching metric.

### 3. Confidence intervals assumed independent repetitions
**Severity** Silent-wrong · **Found by** the author challenging the claim

Intervals were computed as `1.96·SD/√n`, which assumes n independent experiments. Any two
80/20 training partitions share about 80% of their rows, so per-repetition scores are
positively correlated and their mean is far less precise.

**Why it mattered** It understated uncertainty on the headline estimate, in the optimistic
direction.

**Correction** Nadeau–Bengio variance estimate for repeated random train/test resampling
(*Machine Learning* 52:239–281, 2003): `SE = SD·√(1/n + n_test/n_train)`. Both corrected and
naive intervals are reported, the naive one labelled as overstating precision.

**Evidence** Computed, not hardcoded: the factor reports 2.45× at n=20 and 1.22× at n=2.
A consequence worth stating in the manuscript — the naive interval shrinks as `1/√n` while
true uncertainty floors at `SD·√(n_test/n_train)`, so **adding repetitions does not drive
uncertainty to zero**.

### 4. A7's SMOTE arm would have stopped being SMOTE
**Severity** Silent-wrong · **Found by** static inspection before running

A7 built its "SMOTE (as reported)" arm by calling the shared pipeline helper. Once that
helper followed the active framework, the arm would have become a class-weighted model while
still being labelled SMOTE.

**Correction** The SMOTE arm is constructed explicitly via a dedicated function.

**Evidence** The framework test confirms the dedicated function returns
`['scaler', 'smote', 'classifier']` regardless of the active framework.

### 5. Dataset checksums silently absent from headless runs
**Severity** Silent-wrong (provenance) · **Found by** static analysis (pyflakes)

`DATA_FILES` is defined in the interactive upload cell, which the exporter skips. The
manifest guarded the reference, so a headless run recorded **zero** input checksums while
the manifest still appeared complete.

**Correction** The exporter parses the definition out of the notebook and carries it through,
so it cannot drift from the notebook's copy.

**Evidence** Export reports `DATA_FILES carried through: ['assay', 'benchmark', 'broad']`.

### 6. Bit-exact score reproduction was the wrong criterion
**Severity** Silent-wrong (false alarm) · **Found by** execution of the verifier

The restoration verifier demanded bit-exact score equality and failed three models.
Measured deviations were 2.2e-16 to 1.2e-13, while tree models were bit-exact.

**Root cause** Linear and kernel models reach scores through BLAS reductions whose summation
order depends on thread count. The check was testing hardware determinism, not restoration.

**Correction** Predictions must match exactly; scores to `rtol=atol=1e-12`. The observed
deviation is recorded rather than merely compared.

**Evidence** 7 of 8 checkpoints pass with deviations reported per model.

---

## Blocking defects

### 7. `RESULTS_DIR` used five cells before its definition
**Severity** Blocking · **Found by** execution

Defined in the export cell near the end, but appendices A6, A7, A10 and A11 write their
exports while they run. All four raised `NameError`.

**Why it mattered** On the production sequence this fires *after* the multi-hour benchmark —
benchmark tables intact, every appendix lost.

**Correction** Defined in the early setup cell; the export cell re-assigns the same value
harmlessly.

**Evidence** Ordering verified by character offset in the exported source; A6 subsequently
completed.

### 8. `confusion_matrix` not imported in A11
**Severity** Blocking · **Found by** execution

**Correction** Imported locally, so the appendix does not depend on which names an earlier
cell left in scope.

**Evidence** Caught by the new NameError gate when tested against the pre-fix source.

### 9. Bridge assertion assumed the three-step SMOTE pipeline
**Severity** Blocking · **Found by** static inspection before running

`assert list(named_steps) == ['scaler', 'smote', 'classifier']` outside the fit audit would
have crashed every cost-sensitive run at the screening bridge.

**Correction** Made framework-aware. The invariant that matters — that screening receives the
same fitted scaler and forest used for interpretation — is established by two identity
assertions immediately above.

### 10. Custom estimator unpicklable outside the notebook
**Severity** Blocking (for third parties) · **Found by** execution of the verifier

Pickle stores classes by module path. The cost-sensitive XGBoost class lived in `__main__`,
so deposited checkpoints only reloaded inside a session that had re-executed that cell. It
*appeared* to pass inside the notebook because the runner binds the name into `__main__`.

**Correction** Shipped as `cd133_estimators.py`, imported by the notebook, which writes the
module if absent so Colab still runs standalone.

**Evidence** A fresh process that never defines the class loads the checkpoint and uses it.
An assertion confirms `__module__ == 'cd133_estimators'`.

### 11. Isolated interpreters cannot import the shipped module
**Severity** Blocking · **Found by** execution while testing defect 10

`python3 -I` and `-P` drop the working directory from `sys.path`, so the import failed — in
the very headless mode used to produce results.

**Correction** The module's directory is added to `sys.path` explicitly.

---

## Integrity defects

### 12. Exit status masked by the launch command
**Severity** Integrity · **Found by** investigating a suspicious "success"

A run reported "exit code 0" while the analysis had died with `NameError`. The launch command
ended with `echo "EXIT=$?"`, so the shell reported the `echo`'s status.

**Why it mattered** A crashed run looked clean. Earlier "exit code 0" claims in this project
were weaker evidence than presented; the conclusions held only because the logs were also
inspected for content.

**Correction** `set -o pipefail` with `PIPESTATUS[0]`, per the author's recommendation, plus a
launcher that prints completion evidence separately from the status.

**Evidence** Five launcher guards tested against real exit codes; a Python process exiting 42
behind `tee` now yields 42, not 0.

### 13. Checkpoint restoration failures silently refitted
**Severity** Integrity · **Found by** the author's condition 6

**Correction** Failures are recorded with error type, message, environment and the fingerprint
the configuration was verified against. Refitting proceeds only after that verification. The
record exports unconditionally, so an empty file is a positive statement.

### 14. Deprecated `probability` parameter
**Severity** Integrity · **Found by** execution

`SVC(probability=False)` emits a `FutureWarning` on every fit and is removed in
scikit-learn 1.11 — a forward-compatibility hazard for an archive meant to be re-runnable.

**Correction** `SVC()`. Same estimator, no warning, survives the removal.

**Evidence** Verified identical `decision_function` output and `predict_proba` absence; warning
count drops from one-per-fit to zero.

---

## Noise defects

### 15. 76 MB single line of stdout
**Severity** Noise · **Found by** execution (log inspection)

Provenance archives publish as IPython MIME bundles, which collapse in a notebook but dump
the payload headlessly — i.e. under `nbconvert --execute`, exactly how a third party re-runs
the package.

**Correction** `display` is wrapped so bundles are written to files with a one-line pointer
when no frontend exists. Archives previously existed only inside notebook output and were
lost on headless runs, so this also adds them to the package.

**Side finding** The curation archive is 83 MB, above GitHub's 50 MB advisory limit. Archives
over 5 MB are now gzipped; `gzip.open` round-trip verified.

### 16. Per-fit diagnostic flooding the log
**Severity** Noise · **Found by** execution

The "no cost-sensitive mechanism" notice printed on every pipeline construction — hundreds of
identical lines burying benchmark progress.

**Correction** Announced once per estimator type.

---

## Systemic correction

Defects 7 and 8 were the same class: a name resolution error invisible to `compile()`, which
checks syntax and not name resolution. Both surfaced only after expensive work completed. So
rather than fix them individually, the exporter now runs a **NameError gate** (pyflakes) that
refuses to export source referencing any undefined name, while permitting names covered by an
explicit `if 'name' in globals():` guard.

Verified against both real defects: it catches the `confusion_matrix` case and the
`RESULTS_DIR` case, and correctly allows a guarded optional reference. This class of failure
can no longer reach a run.

**What this register says about process.** Ten of seventeen defects were found by execution,
five by static or isolated-component testing, and two by the author questioning a claim I had
presented as settled. The two most expensive classes — late-stage crashes and silently
mislabelled output — were both invisible to code reading. The validation-before-production
sequence the author required is what caught them, at a cost of minutes instead of hours.

---

## Defect 17 — stale dataframe column reference in the dependence caveat
**Severity** Blocking · **Class** Computational execution (it lives in hardening
infrastructure, but by the stated rule a defect is classed by its worst realistic
consequence, and this one aborts a run) · **Found by** execution

The A11 dependence caveat printed `_a11_paired_df["Repeats"]`; the column is `Seeds`.

**Why the NameError gate did not catch it** A missing dict key raises `KeyError` at runtime
and is not an undefined name, so pyflakes cannot see it. The gate closes the `NameError`
class and nothing wider — worth stating plainly, because a gate that is trusted beyond its
actual coverage is worse than no gate.

**Correction** The line now uses the seed list directly rather than indexing a column,
removing the failure mode instead of correcting the name: a column name was a second place
for the same fact to live.

---

## Classification by what each defect actually threatened

Per the author's condition 2. A defect is classed by its worst realistic consequence, not by
where in the code it lived.

### Scientific validity — would have changed or mislabelled a reported result (6)

| # | Defect | Effect if shipped |
|---|---|---|
| 1 | Repeated-splits hyperparameters tuned outside the repetition | Leakage into the primary performance estimate |
| 2 | Previously exposed partition inside the headline estimate | Exposed data in the estimate built to avoid it |
| 3 | Intervals assumed independent repetitions | Uncertainty understated, optimistically |
| 4 | A7's SMOTE arm silently class-weighted | A comparison labelled as something it was not |
| 5 | Dataset checksums absent from headless runs | Provenance claim unsupported while appearing complete |
| 6 | Bit-exact score criterion | False failure; would have discredited sound artifacts |

These six are the set that could have reached the manuscript. Three of them (1, 3, and the
over-claim corrected in the rank-stability check) were identified by the author questioning a
claim, not by any automated check.

### Computational execution — would have aborted a run (6)

| # | Defect | Where it would have fired |
|---|---|---|
| 7 | `RESULTS_DIR` used before definition | After the full benchmark, losing four appendices |
| 8 | `confusion_matrix` not imported | Mid-appendix |
| 9 | Bridge assertion assumed SMOTE steps | At the screening bridge, mid-run |
| 10 | Custom estimator unpicklable externally | Only for third parties, after deposition |
| 11 | Isolated interpreter cannot import the module | At import, in the mode used for production |
| 17 | Stale dataframe column reference | Mid-appendix, after the analysis |

Five of these six would have fired *late* — after the expensive work completed. That is the
specific risk the validation gate addresses, and the reason it paid for itself.

### Reproducibility infrastructure — provenance or usability, numbers unaffected (5)

| # | Defect | Consequence |
|---|---|---|
| 12 | Exit status masked by the launch command | A crashed run read as clean |
| 13 | Checkpoint restoration failures silently refitted | Unrecorded substitution of a refit for a deposited model |
| 14 | Deprecated `probability` parameter | Archive would break on scikit-learn 1.11 |
| 15 | 76 MB stdout line; 83 MB archive | Headless output unusable; package above hosting limits |
| 16 | Per-fit diagnostic flooding the log | Progress unreadable |

### Where the defects originated

Eleven were in the original analysis or its round-5 adaptation. **Six were in code written to
satisfy the hardening conditions themselves** — defects 3, 5, 6, 12, 17 and the rank-stability
over-claim. The defect rate in new hardening code exceeded that in the code being hardened.
This is the evidence behind the author's decision to freeze hardening scope, and it is the
right conclusion: a smaller, thoroughly tested reproducibility system is preferable to an
elaborate one that keeps introducing failure modes.

## Regression evidence for corrected defects

Per condition 4, and deliberately limited to tests that already exist and have been run —
no new test infrastructure was added under the freeze.

| Defect | Regression evidence | Status |
|---|---|---|
| 1 | Per-repetition assertion that the scaler saw only that repetition's rows | in-run, every repetition |
| 2 | Assertion that seed 101 is absent; partition checksums all distinct | in-run |
| 3 | Correction factor computed, not hardcoded; reported 2.45x at n=20, 1.22x at n=2 | observed in two runs |
| 4 | Framework test asserts the SMOTE helper returns `['scaler','smote','classifier']` under either framework | passed |
| 5 | Exporter prints the carried-through `DATA_FILES` keys | passed |
| 6 | Verifier records per-model deviation; 7 of 8 pass with values shown | passed |
| 7, 8, 17 | Exporter NameError gate, verified against defects 7 and 8 directly | passed; does NOT cover 17's class |
| 9 | Cost-sensitive framework test fits all eight classifiers through the bridge path | passed |
| 10, 11 | Fresh process with no hand-defined class loads and uses the checkpoint | passed |
| 12 | Five launcher guards tested against real exit codes; Python exiting 42 behind `tee` yields 42 | passed |
| 13 | Restoration record exported unconditionally, so an empty file is a positive statement | in-run |
| 14 | Verified identical `decision_function` output, `predict_proba` absent, zero warnings | passed |
| 15 | `gzip.open` round-trip equality verified | passed |

Defect 16 has no test; it is cosmetic and a test would cost more than it protects.
