"""Generate the Journal of Cheminformatics manuscript from results_export/.

No number is typed here. Every quantitative statement is read from the files the
notebook writes, so the class of error found in the first review (values present in
the manuscript but in no notebook output) cannot occur.
"""
import json, os, sys
import pandas as pd
import numpy as np
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

R = sys.argv[1] if len(sys.argv) > 1 else 'results_export'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'Manuscript_J_Cheminformatics.docx'


# ---------------------------------------------------------------- loaders
def csv(name, **kw):
    p = os.path.join(R, name)
    if not os.path.exists(p):
        return None
    return pd.read_csv(p, **kw)


def js(name):
    p = os.path.join(R, name)
    if not os.path.exists(p):
        return None
    with open(p) as fh:
        return json.load(fh)


def need(obj, name):
    if obj is None:
        raise SystemExit(f'MISSING required export: {name}. Run the notebook first.')
    return obj


def f(v, n=3):
    """Format a number to n decimals."""
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return 'n/a'
    return f'{float(v):.{n}f}'


COUNT_COLUMNS = {
    'features', 'test n', 'training n', 'n', 'entries', 'predicted active', 'flagged n',
    'below bound', 'above bound', 'below training minimum', 'above training maximum',
    'compounds', 'trees', 'distinct probabilities', 'largest tied block',
    'rotatablebonds', 'hbd', 'hba', 'aromaticrings',
}


def cellf(column, v, n=3):
    """Format one table cell, rendering genuine counts as integers.

    The generic formatter forces three decimals on every numeric value, which printed
    sample sizes and descriptor counts as '681.000' and '74.000'. A blanket integer rule
    is wrong because some bounds are legitimately 0.000, so the column name decides.
    """
    if isinstance(v, (int, float, np.floating)) and np.isfinite(v):
        if str(column).strip().lower() in COUNT_COLUMNS and float(v) == int(v):
            return str(int(v))
        return f(v, n)
    return str(v)


def pct(v, n=1):
    return f'{100 * float(v):.{n}f}%'


def thousands(v):
    return f'{int(v):,}'


# ---------------------------------------------------------------- load all
curation = need(js('curation_counts.json'), 'curation_counts.json')
splits = need(csv('split_populations.csv', index_col=0), 'split_populations.csv')
rfperf = need(csv('designated_rf_performance.csv', index_col=0), 'designated_rf_performance.csv')
cm = need(js('designated_rf_confusion.json'), 'designated_rf_confusion.json')
mdi = need(csv('impurity_importance.csv', index_col=0), 'impurity_importance.csv')
shapr = need(csv('shap_ranking.csv', index_col=0), 'shap_ranking.csv')
shapmeta = js('shap_meta.json')
medians = need(csv('descriptor_medians_by_class.csv', index_col=0), 'descriptor_medians_by_class.csv')
corr = need(csv('descriptor_correlations.csv', index_col=0), 'descriptor_correlations.csv')
scaffold = need(csv('scaffold_partition_summary.csv', index_col=0), 'scaffold_partition_summary.csv')
bench = csv('benchmark_compound_predictions.csv', index_col=0)
adb = need(csv('applicability_domain_bounds.csv', index_col=0), 'applicability_domain_bounds.csv')
adobs = need(csv('broad_observed_ranges.csv', index_col=0), 'broad_observed_ranges.csv')
counts = need(csv('screening_class_counts.csv', index_col=0), 'screening_class_counts.csv')
sample = csv('screening_stratified_sample.csv', index_col=0)
disease = need(csv('disease_area_breakdown.csv', index_col=0), 'disease_area_breakdown.csv')
multi = js('disease_area_meta.json')
overlap = need(csv('collection_overlap.csv', index_col=0), 'collection_overlap.csv')
stability = csv('appendix_seed_stability.csv', index_col=0)
ad_pct = csv('applicability_domain_percentile.csv')
sel_params = csv('selected_parameters_by_combination.csv')
broad_ranges = csv('broad_observed_ranges.csv', index_col=0)
sel_decision = js('appendix_selection_decision.json')
sel_paired = csv('appendix_selection_paired_differences.csv')
sel_matched = csv('appendix_selection_matched_precision.csv')
route = js('svm_scoring_route_summary.json')
env = js('software_environment.json')
UNWEIGHTED = (env or {}).get('estimators fitted unweighted', [])
sweep = csv('appendix_threshold_sweep.csv', index_col=0)
simil = csv('appendix_similarity.csv', index_col=0)
boot = csv('appendix_bootstrap_importance.csv', index_col=0)
gran = js('appendix_granularity.json')
baselines = csv('appendix_baselines.csv', index_col=0)
calib = csv('appendix_calibration.csv', index_col=0)
calmeta = js('appendix_calibration_meta.json')
oof = csv('benchmark_out_of_fold.csv', index_col=0)
held = csv('benchmark_held_out.csv', index_col=0)
versions = js('environment_versions.json')
figman = csv('figure_manifest.csv', index_col=0)

# --- what was actually benchmarked, and whether a winner is resolvable ----------
# The abstract previously asserted a three-representation benchmark and named a winning
# model. Both are claims about the completed run, so both are derived here: an incomplete
# benchmark must not be described as complete, and a margin inside the split-to-split band
# must not be reported as a ranking.
REPS_DONE = sorted(oof['Representation'].unique()) if (oof is not None and len(oof)) else []
N_REPS = len(REPS_DONE)
REP_WORD = {1: 'one molecular representation', 2: 'two molecular representations',
            3: 'three molecular representations'}.get(N_REPS, f'{N_REPS} molecular representations')
_REP_NAMES = {'7 Lipinski descriptors': 'seven RDKit descriptors',
              'ECFP4': '1024-bit ECFP4 fingerprints',
              'Hybrid': 'their 1031-feature hybrid'}
_named = [_REP_NAMES.get(r, str(r)) for r in REPS_DONE]
REP_PHRASE = (' and '.join(_named) if len(_named) < 3
              else ', '.join(_named[:-1]) + ' and ' + _named[-1]) or 'the descriptor representation'
SEED_SD = float(stability['ROC-AUC'].std(ddof=1)) if (stability is not None and 'ROC-AUC' in getattr(stability, 'columns', [])) else None
N_REPEATS = len(stability) if stability is not None else 0
# One resolvability threshold for the whole document, so the tables, the Results text and
# the discussion cannot disagree about what counts as a distinguishable difference. It is
# the Nadeau-Bengio half-width for dependent resampling, not 2*SD: the repetitions share
# compounds, so the ordinary standard error understates the uncertainty of their mean.
if SEED_SD and N_REPEATS > 1:
    RESOLVABLE = float(1.96 * SEED_SD * np.sqrt(1.0 / N_REPEATS + 0.2 / 0.8))
    RESOLVABLE_BASIS = (f'the 95% interval half-width from {N_REPEATS} repeated partitions '
                        f'with the dependence correction applied')
else:
    RESOLVABLE = 0.03
    RESOLVABLE_BASIS = 'a conservative default, repeated-partition spread unavailable'

# How much of each benchmark table is actually orderable. Computed, because a table whose
# adjacent rows differ by less than the uncertainty is a grouping and not a ranking, and
# presenting it as a ranking would overstate the result.
RESOLVE_TOTAL = RESOLVE_UNRESOLVED = 0
TIED_WITH_BEST = 0
if oof is not None and len(oof) and 'ROC-AUC' in oof.columns:
    for _k, _sub in oof.groupby(['Splitting strategy', 'Representation']):
        _v = _sub['ROC-AUC'].sort_values(ascending=False).to_numpy()
        _g = [_v[i] - _v[i + 1] for i in range(len(_v) - 1)]
        RESOLVE_TOTAL += len(_g)
        RESOLVE_UNRESOLVED += sum(1 for _d in _g if _d < RESOLVABLE)
    _best = float(oof['ROC-AUC'].max())
    TIED_WITH_BEST = int((oof['ROC-AUC'] >= _best - RESOLVABLE).sum())
    # The designated model is not the best combination in the benchmark. Whether that gap
    # is real by this paper's own criterion decides whether the choice needs defending, so
    # it is measured here rather than assumed either way.
    _best_row = oof.sort_values('ROC-AUC', ascending=False).iloc[0]
    BEST_LABEL = (f'{_best_row["Model"]} on the {_best_row["Representation"]} representation '
                  f'under {str(_best_row["Splitting strategy"]).lower()} splitting')
    BEST_ROC = float(_best_row['ROC-AUC'])
    BEST_REP = str(_best_row['Representation'])
    _des = oof[(oof['Splitting strategy'] == 'Random')
               & (oof['Representation'] == '7 Lipinski descriptors')
               & (oof['Model'] == 'Random Forest')]
    DESIGNATED_ROC = float(_des['ROC-AUC'].iloc[0]) if len(_des) else None
    DESIGNATED_GAP = (BEST_ROC - DESIGNATED_ROC) if DESIGNATED_ROC is not None else None
    DESIGNATED_GAP_REAL = bool(DESIGNATED_GAP is not None and DESIGNATED_GAP > RESOLVABLE)


tr = curation['training']


def cget(d, *keys, default=None):
    for k in keys:
        if k in d:
            return d[k]
    return default


# training counts
N_INPUT = int(cget(tr, 'Input records'))
N_EXCL = int(cget(tr, 'All exclusions'))
N_MERGED = int(cget(tr, 'Duplicate records merged'))
N_PARENTS = int(cget(tr, 'Final unique model-ready parents'))
N_INACT = int(cget(tr, 'Final Inactive parents'))
N_ACT = int(cget(tr, 'Final Active parents'))
N_CONFLICT = int(cget(tr, 'All conflicting-label parent groups'))

# Is the bounding-box domain capable of excluding anything from the screened library? If
# the training envelope contains the library's observed range on every descriptor, the
# answer is no, by construction rather than by chance - which is a different and much
# stronger statement than "the box is marginal".
DOMAIN_VACUOUS = None
DOMAIN_WIDEST = None
if adb is not None and broad_ranges is not None:
    try:
        _b = adb
        _lo = _b[[c for c in _b.columns if 'min' in c.lower()][0]]
        _hi = _b[[c for c in _b.columns if 'max' in c.lower()][0]]
        _rl = broad_ranges[[c for c in broad_ranges.columns if 'min' in c.lower()][0]]
        _rh = broad_ranges[[c for c in broad_ranges.columns if 'max' in c.lower()][0]]
        _shared = [d for d in _lo.index if d in _rl.index]
        DOMAIN_VACUOUS = all(float(_lo[d]) <= float(_rl[d]) and float(_rh[d]) <= float(_hi[d])
                             for d in _shared)
        _mw = [d for d in _shared if 'ExactMolWt' in str(d)]
        if _mw:
            DOMAIN_WIDEST = (float(_lo[_mw[0]]), float(_hi[_mw[0]]),
                             float(_rl[_mw[0]]), float(_rh[_mw[0]]))
    except Exception:
        DOMAIN_VACUOUS = None

# Share of retained parents whose label depended on source order.
CONFLICT_PCT = (100.0 * N_CONFLICT / N_PARENTS) if (N_CONFLICT and N_PARENTS) else None
N_NEWCONF = int(cget(tr, 'New parent-label conflict groups (legacy representative)',
                     'New parent-label conflict groups (legacy repres...', default=0) or 0)
N_CHARGE = int(cget(tr, 'Final parents with residual formal charges'))
N_USABLE = int(cget(tr, 'Usable records before parent deduplication'))

br = curation.get('broad') or {}
B_INPUT = int(cget(br, 'Input records', default=0))
B_FINAL = int(cget(br, 'Final unique model-ready parents', default=0))
B_UNRES = int(cget(br, 'Final parents with unresolved CX stereo semantics', default=0))

# split populations
sp = splits.reset_index()
def split_row(name):
    m = sp[sp.apply(lambda r: name.lower() in str(r.to_dict()).lower(), axis=1)]
    return m.iloc[0] if len(m) else None

# designated RF rows
def rf_row(split, ev):
    m = rfperf[(rfperf['Splitting strategy'] == split) & (rfperf['Evaluation type'] == ev)]
    return m.iloc[0] if len(m) else None

rand_oof = rf_row('Random', 'OOF')
rand_ho = rf_row('Random', 'Held out')
scaf_oof = rf_row('Scaffold', 'OOF')
scaf_ho = rf_row('Scaffold', 'Held out')

print('Loaded exports. Key values:')
print(f'  parents {N_PARENTS}  active {N_ACT}  inactive {N_INACT}')
if rand_ho is not None:
    print(f"  designated RF random held-out ROC-AUC {rand_ho['ROC-AUC']:.4f} recall {rand_ho['Active-class recall']:.4f}")
print(f'  benchmark combinations exported: {0 if oof is None else len(oof)}')


# ---------------------------------------------------------------- document
doc = Document()
st = doc.styles['Normal']
st.font.name = 'Times New Roman'
st.font.size = Pt(12)
st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
st.paragraph_format.space_after = Pt(6)

sec = doc.sections[0]
sec.page_width, sec.page_height = Inches(8.5), Inches(11)
for m in ('top_margin', 'bottom_margin', 'left_margin', 'right_margin'):
    setattr(sec, m, Inches(1))

# continuous line numbering
sp_el = sec._sectPr
ln = OxmlElement('w:lnNumType')
ln.set(qn('w:countBy'), '1')
ln.set(qn('w:restart'), 'continuous')
ln.set(qn('w:distance'), '360')
sp_el.append(ln)

# Page numbering in the footer. The journal requires line AND page numbering; line
# numbering alone was set, which met half the requirement. A PAGE field is used rather
# than literal text so the numbers follow repagination in the editor's copy.
_footer_p = sec.footer.paragraphs[0]
_footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
_fr = _footer_p.add_run()
for _instr, _attrs in (('begin', {}), (None, {'instr': 'PAGE'}), ('end', {})):
    if _instr:
        _el = OxmlElement('w:fldChar')
        _el.set(qn('w:fldCharType'), _instr)
    else:
        _el = OxmlElement('w:instrText')
        _el.set(qn('xml:space'), 'preserve')
        _el.text = ' PAGE '
    _fr._r.append(_el)
_fr.font.size = Pt(10)


def P(text='', bold=False, italic=False, size=None, after=6, align=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold, r.italic = bold, italic
    if size:
        r.font.size = Pt(size)
    p.paragraph_format.space_after = Pt(after)
    if align:
        p.alignment = align
    return p


def rich(parts, after=6, line_single=False):
    p = doc.add_paragraph()
    for t, b, i in parts:
        r = p.add_run(t)
        r.bold, r.italic = b, i
    p.paragraph_format.space_after = Pt(after)
    if line_single:
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    return p


def H(text, level=1):
    h = doc.add_heading(level=level)
    r = h.add_run(text)
    r.font.name = 'Times New Roman'
    r.font.color.rgb = RGBColor(0, 0, 0)
    r.bold = True
    r.font.size = Pt(14 if level == 1 else 12)
    h.paragraph_format.space_before = Pt(12)
    h.paragraph_format.space_after = Pt(6)
    return h


def caption(label, title):
    p = doc.add_paragraph()
    r = p.add_run(f'{label} {title}')
    r.bold = True
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    return p


def legend(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(10)
    p.paragraph_format.space_after = Pt(10)
    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    return p


def table(headers, rows, widths=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    # BMC: no shading/colour; use plain borders and bold header text
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ''
        pr = hdr[i].paragraphs[0]
        r = pr.add_run(str(h))
        r.bold = True
        r.font.size = Pt(9)
        pr.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        pr.paragraph_format.space_after = Pt(0)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ''
            pr = cells[i].paragraphs[0]
            r = pr.add_run(str(v))
            r.font.size = Pt(9)
            pr.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            pr.paragraph_format.space_after = Pt(0)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    return t


print('Building document...')

# ============================== TITLE PAGE ==============================
p = doc.add_paragraph()
r = p.add_run('An interpretable machine learning framework for the physicochemical '
              'property space of compounds active in CD133⁺ glioblastoma phenotypic screening')
r.bold = True
r.font.size = Pt(14)

_ap = doc.add_paragraph()
_ap.add_run('Edmund Essah Ameyaw')
_r = _ap.add_run('1*'); _r.font.superscript = True
_ap.add_run(' and Byran Woodside II')
_r = _ap.add_run('1'); _r.font.superscript = True
_ap.paragraph_format.space_after = Pt(6)

_af = doc.add_paragraph()
_r = _af.add_run('1'); _r.font.superscript = True
_r = _af.add_run(' Department of Pharmaceutical Sciences, College of Pharmacy, Howard University, '
                 '2300 4th Street NW, Washington, DC 20059, USA'); _r.italic = True
_af.paragraph_format.space_after = Pt(6)
rich([('*Corresponding author: ', True, False),
      ('Edmund Essah Ameyaw, Department of Pharmaceutical Sciences, College of Pharmacy, '
       'Howard University, 2300 4th Street NW, Washington, DC 20059, USA. '
       'Email: edmundessah.ameyaw@howard.edu', False, False)])
rich([('ORCID: ', True, False), ('EEA [INSERT ORCID]; BW [INSERT ORCID]', False, False)])

# ============================== ABSTRACT ==============================
H('Abstract', 1)

abs_sections = [
 ('Background', 'Phenotypic screening in CD133⁺ glioblastoma stem cell (GSC) research '
  'yields compound activity data, but bulk physicochemical associations require careful '
  'interpretation. We built an interpretable machine learning framework to characterise '
  'these associations without inferring CD133 binding or cell-specific selectivity.'),

 ('Scientific Contribution',
  f'This work delivers a leak-controlled benchmark of eight classifiers across {REP_WORD} '
  f'on pooled CD133⁺ GSC data, with scaling and cost-sensitive class weighting '
  'confined to training folds under random and scaffold validation. It pairs a seven-descriptor '
  'Random Forest with held-out Shapley explanations, compound-level bootstrap importance '
  'intervals and an audited applicability domain, with every reported value '
  'emitted machine-readably rather than transcribed. It quantifies the operating-point, '
  'split-variability, similarity and calibration limits bounding each claim.'),

 ('Methods', f'PubChem BioAssay AID 1345199 records were pooled across four glioblastoma-related '
  f'panels and an astrocyte panel. '
  f'yielding {thousands(N_PARENTS)} curated assay parents. Eight classifiers were benchmarked '
  f'on {REP_PHRASE} under random and '
  f'Bemis–Murcko scaffold splitting, each tuned by ROC-AUC inside nested folds with '
  f'class weighting applied inside each training fold. A designated seven-descriptor Random Forest was '
  f'interpreted with impurity importance, held-out Shapley explanations and bootstrap '
  f'intervals, then applied to five literature compounds and {thousands(int(counts["entries"].sum()))} '
  f'repurposing library entries under training-derived bounds.'),

 ('Results', 'PLACEHOLDER_RESULTS'),

 ('Conclusion', 'The framework characterises model-associated physicochemical patterns and '
  'supplies computational priorities for follow-up. Pooled panel labels, conflicting outcomes, '
  'analogue similarity across the random split and collection overlap restrict interpretation. '
  'Predictions do not establish CD133 binding, selective GSC cytotoxicity, blood-brain barrier '
  'penetration or independent biological validation.'),
]

# --- Results abstract sentence, generated from the exports ---
res_bits = []
if oof is not None and len(oof):
    _ranked = oof.sort_values('ROC-AUC', ascending=False)
    top = _ranked.iloc[0]
    _gap = float(top['ROC-AUC']) - float(_ranked.iloc[1]['ROC-AUC']) if len(_ranked) > 1 else None
    if _gap is not None and _gap < RESOLVABLE:
        _close = _ranked[_ranked['ROC-AUC'] >= float(top['ROC-AUC']) - RESOLVABLE]
        _names = ', '.join(dict.fromkeys(str(m) for m in _close['Model']))
        res_bits.append(
            f"Out-of-fold ROC-AUC peaked at {f(top['ROC-AUC'])} ({top['Model']}), but the "
            f"leading models fall within the repeated-split band and are not separated here.")
    else:
        res_bits.append(f"The strongest out-of-fold discrimination came from {top['Model']} on the "
                        f"{top['Representation']} representation under {str(top['Splitting strategy']).lower()} "
                        f"splitting (ROC-AUC {f(top['ROC-AUC'])}).")
_scaf_txt = (f"; the separately fitted scaffold model reached {f(scaf_ho['ROC-AUC'])}"
             if scaf_ho is not None else "")
res_bits.append(
    f"The seven-descriptor Random Forest was designated for interpretability despite that "
    f"gap, and reached out-of-fold ROC-AUC "
    f"{f(rand_oof['ROC-AUC'])} and held-out ROC-AUC {f(rand_ho['ROC-AUC'])} "
    f"(accuracy {f(rand_ho['Accuracy'])}, precision {f(rand_ho['Active-class precision'])}, "
    f"recall {f(rand_ho['Active-class recall'])}){_scaf_txt}.")
if stability is not None and len(stability):
    res_bits.append(f"Across {len(stability)} random splits held-out ROC-AUC was "
                    f"{f(stability['ROC-AUC'].mean())} ± {f(stability['ROC-AUC'].std())}, so "
                    f"differences below {f(RESOLVABLE)} are not resolvable.")
if sweep is not None and len(sweep):
    d = sweep.set_index('Threshold') if 'Threshold' in sweep.columns else sweep
    try:
        base = d.loc[0.5]
        alt = d.loc[0.4]
        res_bits.append(
            f"Sensitivity depends mainly on the operating point: at the default 0.5 cut-off the "
            f"false negative rate was {pct(base['FNR'])}, falling to {pct(alt['FNR'])} at 0.4 for "
            f"a precision change from {f(base['Active precision'])} to {f(alt['Active precision'])}.")
    except Exception:
        pass
_act = int(counts.loc['Active', 'entries']) if 'Active' in counts.index else int(counts['entries'].max())
_tot = int(counts['entries'].sum())
res_bits.append(f"Screening classified {_act} of {_tot} entries ({pct(_act/_tot)}) as Active; all "
                f"satisfied the descriptor bounds.")
abs_sections[3] = ('Results', ' '.join(res_bits))

abs_words = sum(len(k.split()) + len(v.split()) for k, v in abs_sections)
print(f'Abstract: {abs_words} words (limit 350)')
if abs_words > 350:
    print('  WARNING: abstract over limit; trimming the Results section.')
    # Trim from the end. The previous version popped res_bits[0], which silently deleted
    # the headline finding - the one sentence the abstract most needs - and left no trace
    # in the output that anything had been removed.
    while abs_words > 350 and len(res_bits) > 2:
        _dropped = res_bits.pop()
        print(f'  dropped from Results: "{_dropped[:90]}..."')
        abs_sections[3] = ('Results', ' '.join(res_bits))
        abs_words = sum(len(k.split()) + len(v.split()) for k, v in abs_sections)
    print(f'  trimmed to {abs_words} words')

for k, v in abs_sections:
    rich([(k + ' ', True, False), (v, False, False)])

rich([('Keywords ', True, False),
      ('Cheminformatics · Machine learning · Glioblastoma stem cells · CD133 · '
       'Random Forest · SHAP interpretability · Applicability domain · Drug repurposing',
       False, False)])

# ============================== INTRODUCTION ==============================
H('Introduction', 1)
P('Glioblastoma is an aggressive primary brain tumour in which stem-like, tumour-initiating '
  'populations contribute to therapeutic resistance and recurrence. CD133 is a marker associated '
  'with some of these populations, and early brain tumour-initiating cell studies established its '
  'relevance to the cancer stem cell framework [1, 2]. CD133-associated biology is heterogeneous '
  'and context dependent; marker expression and phenotypic susceptibility do not establish that a '
  'compound binds the CD133 protein [3].')
P('Machine learning supports data analysis and predictive modelling throughout pharmaceutical '
  'research [4, 5]. In glioblastoma specifically it has been used to examine molecular '
  'heterogeneity and build prognostic models [6], while a complementary line of work examines '
  'compounds active against glioblastoma stem cells, such as the investigation of pyrvinium in '
  'CD133⁺ brain tumour-initiating cells [7]. Within computational drug discovery, classifiers '
  'relate molecular fingerprints and physicochemical descriptors to measured activity labels, as '
  'in dengue virus and CYP1B1 inhibitor prioritisation [8, 9]. Modelling blood-brain barrier '
  'permeability is relevant context for central nervous system discovery [10, 11], although a '
  'viability classifier alone cannot establish permeability.')
P('High-throughput phenotypic screening provides a complementary source of compound-response data. '
  'PubChem BioAssay AID 1345199 reports drug repurposing screens using cells derived from '
  'glioblastoma tumours, including CD133⁺ neurosphere cultures and astrocyte controls [12]. '
  'The present workflow uses pooled assay outcomes to examine bulk physicochemical activity '
  'profiles. Mechanistic deconvolution and confirmation of target engagement require investigation '
  'beyond phenotypic activity classification.')
P('Two methodological problems recur in this setting. The first is leakage: when resampling or '
  'scaling is fitted before partitioning, validation estimates are optimistic. The second is that '
  'reported comparisons often mix tuned and untuned estimators, so a ranking measures tuning effort '
  'rather than algorithm behaviour. A third, less discussed, is transcription: when results are '
  'read off a notebook and typed into a manuscript, values can enter the paper that appear in no '
  'analysis output.')
P('The bulk physicochemical property patterns associated with compounds active in CD133⁺ '
  'neurosphere screening remain incompletely characterised. Seven global descriptors provide an '
  'accessible basis for interpretation but cannot resolve all differences in connectivity, '
  'functional groups or stereochemistry, so comparison with extended-connectivity fingerprints is '
  'needed to assess how much predictive information the bulk properties retain [13]. Because the '
  'dataset pools several cell panels and retains source-order labels, the resulting classifier '
  'cannot establish culture-specific cytotoxicity or selectivity for CD133⁺ cells over '
  'astrocytes.')
P('This study aimed to: (1) benchmark eight classifiers across three representations under a '
  'single tuning protocol with preprocessing contained inside training folds; (2) compare random '
  'and scaffold-based validation; (3) characterise a designated seven-descriptor Random Forest '
  'using impurity importance, held-out Shapley explanations and compound-level bootstrap intervals; '
  '(4) profile literature benchmark compounds and a repurposing library with a training-derived '
  'applicability domain; and (5) quantify the operating-point, split-variability, similarity, '
  'baseline and calibration limits that bound these results.')

# ============================== METHODS ==============================
H('Materials and methods', 1)

H('Dataset acquisition and biological endpoint', 2)
P(f'The source PubChem AID 1345199 table contained {thousands(N_INPUT + 10)} rows. After removal of '
  f'10 metadata rows, {thousands(N_INPUT)} chemical records remained. The assay concerns phenotypic '
  f'viability in patient-derived neurosphere screening rather than a biochemical binding assay for '
  f'CD133 [12]. The supplied table pooled panel labels astro, 206, 308, 827 and 923; the astrocyte '
  f'panel was retained. Source outcomes were encoded Active = 1 and Inactive = 0, without '
  f'panel-specific filtering or new selectivity labels.')
P('Five literature compounds were retained for in silico profiling: pyrvinium, salinomycin, '
  'LDN193189, temozolomide and metformin. Their literature contexts differ [7, 14–17] and were '
  'not treated as a uniform, independently measured validation endpoint. The supplied Broad '
  'Institute Drug Repurposing Hub subset provided structures and source annotations for mechanism, '
  'target and disease area [18]; annotations were used for context and regulatory status was not '
  'independently assessed.')

H('Computational environment and reproducibility', 2)
_v = versions or {}
P('Analyses ran in Python with pandas, NumPy, Matplotlib, Seaborn, scikit-learn, imbalanced-learn, '
  'XGBoost, RDKit and SHAP [19–23]. Exact versions for the reported run were '
  + ', '.join(f'{k} {v}' for k, v in _v.items() if k in
               ('rdkit', 'shap', 'scikit-learn', 'pandas', 'numpy', 'imbalanced-learn', 'xgboost'))
  + '. Versions are asserted at import so a mismatched environment is reported rather than silently '
    'producing different output.')
P('Two reproducibility measures were added in response to internal review. Each '
  '(split, representation, model) result is checkpointed on completion and reloaded rather than '
  'refitted, so the multi-hour benchmark can be run in sittings and an interrupted session does not '
  'restart from zero. Separately, every quantity reported in this manuscript is written by the '
  'analysis to a machine-readable results directory, and the tables and figures here are generated '
  'from those files rather than transcribed by hand.')

H('Structure curation and parent identity', 2)
P('The same curation preceded feature calculation for the assay, repurposing and benchmark '
  'collections. RDKit SaltRemover used default definitions plus documented whole-fragment '
  'definitions; salt stripping was applied to disconnected structures and empty products were '
  'excluded. Neutralisation retained necessary formal charges. Missing structures, parsing or '
  'sanitisation failures, empty products and unresolved mixtures were excluded with recorded '
  'reasons. Canonical identity-only CXSMILES preserved stereochemistry, isotopes, necessary charges '
  'and enhanced stereo groups; names, coordinates, atom maps and arbitrary properties were excluded '
  'from identity. No tautomer normalisation or global removal of stereochemistry was performed '
  '[22, 24].')
P('Unverified structural CX annotations were preserved and flagged with conservative merge guards. '
  'Source-order deduplication retained the first parent and its original outcome, without averaging '
  'or adjudicating conflicting assay labels. RDKit messages emitted during curation are captured to '
  'a log retained with the provenance archive rather than suppressed.')

H('Molecular representations', 2)
P('Seven fixed physicochemical descriptors were calculated: MolLogP, topological polar surface '
  'area (TPSA), exact molecular weight (ExactMolWt), rotatable bonds, hydrogen-bond donors (HBD), '
  'hydrogen-bond acceptors (HBA) and aromatic rings. They describe bulk properties related to, but '
  'not identical with, the rule of five [25]. ECFP4 used RDKit Morgan fingerprints of radius 2 and '
  '1024 binary bits; the hybrid concatenated both, giving 1031 features [13, 22]. Real-compound '
  'fingerprints remained binary. No feature-selection procedure was used.')

H('Splits and fold-contained preprocessing', 2)
_rand = splits.loc['Random'] if 'Random' in splits.index else splits.iloc[0]
_scaf = splits.loc['Scaffold'] if 'Scaffold' in splits.index else splits.iloc[1]
P(f'A stratified random 80/20 split used seed 101. A separate scaffold benchmark grouped compounds '
  f'by RDKit Bemis–Murcko scaffold SMILES without chirality [22, 26], ordered groups by '
  f'descending size, and assigned each to training while it fitted within 80% of the collection. '
  f'This allocation uses neither outcomes nor performance. Each strategy produced '
  f'{thousands(int(_rand["Training N"]))} training and {thousands(int(_rand["Test N"]))} held-out '
  f'parents with different memberships and class proportions.')
P('Within training data, five-fold stratified cross-validation was used for the random split and '
  'five-fold stratified group cross-validation for the scaffold split, preserving scaffold groups '
  'in outer, inner and final-search folds. Scaffold splitting assesses transfer across held-out '
  'frameworks; it does not establish independence from all structural analogues [27].')
rich([('Each pipeline fitted StandardScaler, then a class-weighted classifier. ', False, False),
      ('Cost-sensitive learning is the designated framework, and it was chosen for '
       'representation integrity rather than for performance. ', True, False),
      ('Class weighting rescales the loss contribution of each class and generates no new '
       'observations, so no interpolated feature vector enters training. That matters most '
       'for the fingerprint representations: interpolating between binary ECFP4 bits '
       'produces vectors that correspond to no real molecule, and such vectors are '
       'chemically uninterpretable however well they balance the classes. Weights are '
       'derived from the labels of the rows each estimator is actually fitted on, so they '
       'are recomputed inside every training fold and no evaluation label influences them. '
       'Validation and held-out sets contained only original compounds at their observed '
       'class ratios.', False, False)])
_cw_note = []
if UNWEIGHTED:
    _cw_note.append(
        'Two estimators require comment. XGBoost provides no class_weight parameter, so the '
        'equivalent balanced weights are supplied as per-fit sample weights, which reproduces '
        'the same weighting exactly while remaining fold-contained. '
        + ('k-nearest neighbours has no class-weighting mechanism at all: its weighting '
           'parameter weights neighbours by distance, which is not class reweighting and was '
           'not substituted for it. That estimator is therefore fitted unweighted and is '
           'labelled as such in the benchmark tables; its rows are comparable across '
           'representations but not to the weighted estimators alongside them.'
           if any('KNeighbors' in str(m) for m in UNWEIGHTED) else ''))
if _cw_note:
    P(' '.join(_cw_note))
P('Oversampling was not discarded. The Synthetic Minority Over-sampling Technique [20, 28] '
  'is retained as a secondary comparative benchmark and its results are reported below, so '
  'the choice of framework rests on a measured comparison rather than on assertion.')

H('Choice of imbalance-handling framework', 2)
if sel_decision and sel_paired is not None and len(sel_paired):
    _sp = sel_paired.set_index('Metric')
    _roc_d = _sp.loc['ROC-AUC']
    _pr_d = _sp.loc['PR-AUC']
    _rec_d = _sp.loc['Recall'] if 'Recall' in _sp.index else None
    _spec_d = _sp.loc['Specificity'] if 'Specificity' in _sp.index else None
    P(f'The two frameworks were compared on pooled training out-of-fold predictions only, '
      f'over {sel_decision.get("fold_seeds") and len(sel_decision["fold_seeds"])} fold seeds '
      f'with identical folds for every variant, leaving the held-out partition unread '
      f'(Additional file 1). Hyperparameters were held at the values tuned under '
      f'oversampling, which handicaps class weighting and makes the comparison '
      f'conservative. Discrimination was indistinguishable: the paired difference in '
      f'ROC-AUC was {f(_roc_d["Mean difference"], 4)} with a 95% interval of '
      f'[{f(_roc_d["95% CI low"], 4)}, {f(_roc_d["95% CI high"], 4)}], and in PR-AUC '
      f'{f(_pr_d["Mean difference"], 4)} '
      f'[{f(_pr_d["95% CI low"], 4)}, {f(_pr_d["95% CI high"], 4)}].')
    if _rec_d is not None and _spec_d is not None and sel_matched is not None:
        _ms = sel_matched.set_index('Variant')['Recall at SMOTE-matched precision']
        rich([('Class weighting did not improve recall as a property of the model. ', True, False),
              (f'At the fixed 0.5 threshold its recall was {f(_rec_d["Mean difference"], 4)} '
               f'higher, but its specificity was {f(abs(_spec_d["Mean difference"]), 4)} '
               f'lower: the classifier was operating at a different point on essentially the '
               f'same curve. Holding the false-positive burden equal by matching precision '
               f'removes the difference entirely, with recall '
               f'{f(_ms.get("SMOTE"), 4)} under oversampling against '
               f'{f(_ms.get("class_weight"), 4)} under class weighting. The framework was '
               f'therefore designated for the reasons given above, and no claim of improved '
               f'recall or discrimination is made for it.', False, False)])
    P('Because this comparison informed the choice of framework, the single held-out '
      'partition it was first explored on is reported as a supplementary, previously '
      'examined result rather than as independent confirmation, and the primary performance '
      'estimate comes from repeated partitions that exclude it.')

H('Classifiers, tuning and evaluation', 2)
P('The eight classifiers were logistic regression, elastic net-regularised logistic regression, '
  'k-nearest neighbours, a support vector machine, a Gini decision tree, an entropy decision tree, '
  'Random Forest and XGBoost. Tuned estimators used five outer folds for out-of-fold evaluation and '
  'five inner folds for grid search, with final searches restricted to the training partition.')
rich([('All searches score ROC-AUC. ', True, False),
      ('Inner validation folds are real and class-imbalanced, so accuracy is weakly discriminating '
       'and biased toward majority prediction; tuning now optimises the metric the study reports. '
       'Both decision trees search depth and leaf size, and XGBoost searches depth, learning rate '
       'and estimator count, so no estimator in the comparison is left at library defaults while '
       'others are tuned. Logistic regression is retained deliberately untuned as an unregularised '
       'linear baseline rather than a competitor; the elastic net is the tuned linear model. '
       'Search ranges are given in Additional file 1, Table S1.', False, False)])
rich([('The Random Forest is fixed at 500 trees with a search over maximum depth, minimum leaf size '
       'and feature subsampling. ', True, False),
      ('Tree count is a convergence rather than a capacity parameter for a forest, and a small '
       'forest quantises predicted probabilities: with 30 trees the output can only take multiples '
       'of 1/30, which produced large blocks of exactly tied compounds in an earlier screening '
       'ranking. Fixing the forest large enough removes that artefact and leaves the search to the '
       'parameters that control model complexity.', False, False)])
if route:
    rich([('The support vector machine is scored by its decision function. ', True, False),
          (f'Ranking metrics are rank-invariant, so a monotone score is sufficient for '
           f'ROC-AUC and PR-AUC, and the decision function is the estimator\u2019s native '
           f'one. The alternative, internal Platt scaling, fits a cross-validated logistic '
           f'calibration inside every grid-search fit and was measured here at '
           f'{f(route.get("Grid-search speedup factor"), 2)} times the cost for the same '
           f'nested search. The two routes are both accepted measures of discrimination but '
           f'are not numerically identical: over the same folds they differed by '
           f'{route.get("ROC-AUC difference (decision - Platt)"):.2e} in ROC-AUC with a '
           f'Spearman rank correlation of '
           f'{f(route.get("Spearman rank correlation of scores"), 6)}, so the rankings agree '
           f'closely without being identical. Decision-function values are unbounded and '
           f'uncalibrated, so no probability-dependent quantity \u2014 Brier score, '
           f'reliability curve or probability band \u2014 is computed for this estimator; '
           f'every such analysis reported here concerns the Random Forest.', False, False)])

if sel_params is not None and 'Distinct settings across outer folds' in sel_params.columns:
    _tuned = sel_params[sel_params['Selected parameters (final training-only search)'] != 'untuned']
    if len(_tuned):
        _d = _tuned['Distinct settings across outer folds']
        _unstable = int((_d > 1).sum())
        rich([('Selected hyperparameters are not stable, and we report this rather than only '
               'the chosen values. ', True, False),
              (f'Across the {len(_tuned)} tuned combinations the five outer folds selected '
               f'between {int(_d.min())} and {int(_d.max())} distinct configurations, with '
               f'more than one configuration chosen in {_unstable} of {len(_tuned)}. The '
               f'setting reported for each combination is therefore the one selected on its '
               f'full training partition, not a configuration the data identify uniquely. '
               f'The same instability appears at the level of repeated partitions for the '
               f'designated model, and both are consistent with a tuning surface that is '
               f'flat over a range of settings rather than sharply peaked. A single tuned '
               f'configuration quoted from one partition would imply a precision these data '
               f'do not support. Per-combination settings and counts are given in Additional '
               f'file 1, Table S1.', False, False)])

P('Accuracy, Active-class precision, recall, F1 and ROC-AUC were computed from pooled real-compound '
  'out-of-fold predictions and separately from untouched held-out predictions. Because only one '
  'random and one scaffold partition underlie the main tables, the designated model was additionally '
  'refitted across repeated random splits to estimate split-to-split variability, and no claim of '
  'statistical superiority is made from differences within that band.')

H('Interpretation', 2)
_nb_trees = (gran or {}).get('n_trees')
P(f'Mean decrease in impurity was extracted from each tree of the designated forest. Across-tree '
  f'spread is reported as a descriptive interval only: the trees are correlated bootstrap resamples '
  f'of one training set, and that spread narrows as trees are added while sampling uncertainty does '
  f'not. A compound-level bootstrap, refitting the forest on resampled training compounds, supplies '
  f'the interval used for any inferential statement. Impurity importance is additionally biased '
  f'toward continuous and high-cardinality predictors and supplies no direction of effect [29].')
_bg = (shapmeta or {}).get('shap_background_rows')
P(f'Tree SHAP supplemented impurity importance using the real held-out parents with a background of '
  f'{_bg if _bg else "sampled"} real training compounds [23, 30]. SHAP explained the probability of '
  f'Active = 1 for the fitted forest on scaled inputs, with plot axes in original units. The '
  f'background is passed through an explicit masker because the library otherwise subsamples it '
  f'silently, which would make the reported base value describe a different population from the one '
  f'it is checked against. Probability reconstruction and model invariance were verified. '
  f'Attribution describes the fitted model relative to its background, not a causal effect.')

H('Profiling, screening and applicability domain', 2)
P('Curated literature and repurposing structures were processed with the same descriptors and the '
  'fitted pipeline. Rule-of-five violations were '
  'counted as screening heuristics that do not establish exposure, permeability or efficacy '
  '[25, 31]. The applicability domain was defined by the inclusive minimum and maximum of each '
  'descriptor across the real training parents, using both classes; bounds used neither weighted '
  'data, held-out compounds nor library values. Bounding is a permissive marginal assessment: it '
  'does not capture descriptor correlations, sparse combinations inside the envelope, or proximity '
  'to an informative training neighbourhood [32], so in-domain status means range compliance rather '
  'than reliability.')

H('Use of large language models', 2)
P('Generative AI tools were used under author direction to support project planning, literature '
  'organisation, development and debugging of the computational notebook, review of analytical '
  'outputs, preparation of tables and figures, and drafting and revision of the manuscript. AI '
  'assistance included checking consistency between reported results and saved computational '
  'outputs. Experimental records came from the cited data sources and all reported model results '
  'were produced by the documented analyses; generative AI was not treated as a source of '
  'experimental evidence or biological validation. Large language models do not meet authorship '
  'criteria and are not listed as authors. The authors retain full responsibility for study design, '
  'verification of code and results, accuracy and attribution of sources, interpretation and the '
  'final manuscript.')

# ============================== RESULTS ==============================
H('Results', 1)

H('Curation accounting and validation populations', 2)
P(f'Curation retained {thousands(N_PARENTS)} assay parents, comprising {thousands(N_INACT)} Inactive '
  f'({pct(N_INACT/N_PARENTS)}) and {thousands(N_ACT)} Active ({pct(N_ACT/N_PARENTS)}) labels '
  f'(Table 1). Of {thousands(N_INPUT)} chemical records, {N_EXCL} were excluded and '
  f'{thousands(N_MERGED)} duplicate records were merged. {N_CONFLICT} parent groups carried '
  f'conflicting source labels and the first source label was retained in each case; '
  f'{N_CHARGE} parents retained necessary formal charges.')

caption('Table 1', 'Reconciled curation counts across the three compound collections')
_stages = ['Input records', 'Missing structures (excluded)',
           'Parsing/sanitization/curation failures (excluded)',
           'Empty salt-stripping products (excluded)',
           'Unresolved multicomponent records (excluded)',
           'User-directed Broad record exclusions (excluded)', 'All exclusions',
           'Usable records before parent deduplication', 'Duplicate records merged',
           'Final unique model-ready parents']
_cols = [('Assay', curation.get('training') or {}),
         ('Broad Institute', curation.get('broad') or {}),
         ('Benchmarks', curation.get('benchmark') or {})]
_rows = []
for s in _stages:
    row = [s.replace(' (excluded)', ' excluded')]
    for _, d in _cols:
        v = d.get(s)
        row.append('' if v is None else (f'{int(float(v))}' if str(v).replace('.','',1).isdigit() else str(v)))
    _rows.append(row)
table(['Stage', 'Assay', 'Broad Institute', 'Benchmarks'], _rows, widths=[3.1, 1.2, 1.3, 1.2])
legend('Counts are read directly from the curation audit written by the analysis. The assay input '
       'excludes 10 metadata rows from the raw table. Broad Institute entries follow the '
       'conservative stereochemical identity policy; guarded entries are not claimed to be fully '
       'resolved unique chemical entities. Blank cells indicate a stage that does not arise for '
       'that collection.')

caption('Table 2', 'Real-compound populations used for random and scaffold validation')
_r2 = []
for idx, row in splits.iterrows():
    _r2.append([str(idx)] + [str(int(row[c])) if isinstance(row[c], (int, float, np.integer, np.floating))
                             and float(row[c]).is_integer() else str(row[c]) for c in splits.columns])
table(['Split'] + [str(c) for c in splits.columns], _r2,
      widths=[1.2] + [5.3/len(splits.columns)]*len(splits.columns))
_sc_d = {}
try:
    _sc_col = scaffold.columns[-1]
    _sc_d = {str(k): scaffold.loc[k, _sc_col] for k in scaffold.index}
except Exception:
    pass
legend('Class proportions differ between the two held-out sets because scaffold allocation is blind '
       'to class, so accuracy and F1 are not directly comparable between splits. '
       + (f"The scaffold partition comprises {int(float(_sc_d.get('scaffold_groups', 0)))} groups; "
          f"the empty/acyclic group of {int(float(_sc_d.get('empty_acyclic_group_size', 0)))} compounds "
          f"is assigned to training in its entirety." if _sc_d else ''))

H('Exploratory physicochemical patterns', 2)
_mA = medians.loc[1] if 1 in medians.index else medians.iloc[-1]
_mI = medians.loc[0] if 0 in medians.index else medians.iloc[0]
P(f'Active-labelled parents had higher median MolLogP ({f(_mA["MolLogP"])} versus '
  f'{f(_mI["MolLogP"])}) and ExactMolWt ({f(_mA["ExactMolWt"])} versus {f(_mI["ExactMolWt"])} Da), '
  f'and lower median TPSA ({f(_mA["TPSA"])} versus {f(_mI["TPSA"])} Å²) than '
  f'Inactive-labelled parents. Distributions overlapped, so none of these summaries established a '
  f'single-property activity rule (Fig. 2; Additional file 1, Figure S1). These are descriptive '
  f'associations with the retained pooled labels, computed on the full curated dataset including '
  f'compounds that later form the held-out sets.')
P(f'Several descriptors were strongly correlated: Pearson r was {f(corr.loc["TPSA","HBA"])} for '
  f'TPSA–HBA, {f(corr.loc["TPSA","HBD"])} for TPSA–HBD and '
  f'{f(corr.loc["ExactMolWt","HBA"])} for ExactMolWt–HBA, while MolLogP and TPSA were '
  f'negatively correlated (r = {f(corr.loc["MolLogP","TPSA"])}; Fig. 3). These relationships '
  f'complicate attribution of independent effects and indicate overlapping information among the '
  f'seven properties.')

H('Comparative benchmark across representations and splits', 2)
# Metric set as prespecified: precision, recall, specificity, F1, balanced accuracy,
# ROC-AUC and PR-AUC. Plain accuracy is deliberately absent from the primary tables - on a
# collection that is roughly two-thirds inactive it rewards majority prediction - and is
# reported in Additional file 1 instead.
_bench_cols = ['Representation', 'Model', 'Active-class precision', 'Active-class recall',
               'Specificity', 'Active-class F1-score', 'Balanced accuracy', 'ROC-AUC', 'PR-AUC']
_hdr = ['Representation', 'Model', 'Precision', 'Recall', 'Specificity', 'F1',
        'Balanced acc.', 'ROC-AUC', 'PR-AUC']
_BENCH_WIDTHS = [0.72, 1.45, 0.62, 0.58, 0.68, 0.52, 0.72, 0.62, 0.58]


def bench_rows(df, strategy):
    """Rows ordered by ROC-AUC, with every model indistinguishable from the group's best
    marked. The mark is what keeps the table honest: ordering rows implies a ranking, and
    most adjacent differences here are smaller than the uncertainty."""
    out = []
    sub = df[df['Splitting strategy'] == strategy] if 'Splitting strategy' in df.columns else df
    for _rep in REPS_DONE:
        part = sub[sub['Representation'] == _rep].sort_values('ROC-AUC', ascending=False)
        if not len(part):
            continue
        top = float(part['ROC-AUC'].iloc[0])
        for _, r in part.iterrows():
            tied = float(r['ROC-AUC']) >= top - RESOLVABLE
            label = str(r['Model']) + ('†' if tied else '')
            cells = [str(r['Representation']).replace('7 Lipinski descriptors', '7D'), label]
            for col in _bench_cols[2:]:
                cells.append(cellf(col, r[col]) if col in r.index else '—')
            out.append(cells)
    return out


def bench_legend(extra=''):
    """Shared legend text: the grouping mark, and how the SVM was scored."""
    parts = [
        '7D seven physicochemical descriptors; ECFP4 1024-bit Morgan radius-2 fingerprints; '
        'Hybrid 1031 features. Precision, recall and F1 concern Active = 1. Metrics pool real '
        'out-of-fold observations; tuned estimators use nested cross-validation with a ROC-AUC '
        'search objective.',
        f'† marks every model whose ROC-AUC is within {f(RESOLVABLE)} of the best in its '
        f'representation, that margin being {RESOLVABLE_BASIS}. Marked models are not '
        f'distinguished by these data and the row order among them carries no meaning.',
        'Logistic regression is an untuned unregularised baseline and is not a tuned '
        'competitor; the elastic net is the tuned linear model.',
    ]
    if UNWEIGHTED and any('KNeighbors' in str(m) for m in UNWEIGHTED):
        parts.append('k-nearest neighbours admits no class weighting and is fitted unweighted; '
                     'its values are comparable across representations but not to the '
                     'class-weighted estimators in the same table.')
    if route:
        parts.append('Support vector machine ranking metrics (ROC-AUC, PR-AUC) are computed '
                     'from decision-function scores rather than predicted probabilities; all '
                     'other estimators use predicted probabilities.')
    if extra:
        parts.append(extra)
    return ' '.join(parts)


BENCH_COMPLETE = oof is not None and len(oof) == 48
if oof is not None and len(oof):
    _nr = len(oof[oof['Splitting strategy'] == 'Random']) if 'Splitting strategy' in oof.columns else len(oof)
    _ns = len(oof) - _nr
    if BENCH_COMPLETE:
        P('Tables 3 and 4 report all 24 training out-of-fold model–representation combinations '
          'for each splitting strategy, with every estimator tuned under the same ROC-AUC objective '
          'inside the same nested folds. Complete held-out results are provided in Additional '
          'file 1, Tables S2 and S3.')
    else:
        P(f'Tables 3 and 4 report the model–representation combinations completed for this '
          f'revision ({_nr} random-split and {_ns} scaffold-split of 24 each). Every estimator is '
          f'tuned under the same ROC-AUC objective inside the same nested folds. Because the full '
          f'benchmark is a multi-hour computation it is checkpointed per combination; the remaining '
          f'combinations reload from cache and do not alter the designated model, its '
          f'interpretation or the screening results reported below.')
    # How orderable these tables actually are, stated before the reader meets them.
    if RESOLVE_TOTAL:
        rich([('These tables group models; they do not rank them. ', True, False),
              (f'{RESOLVE_UNRESOLVED} of {RESOLVE_TOTAL} adjacent pairs across the six '
               f'representation-by-split groups differ by less than {f(RESOLVABLE)} in '
               f'ROC-AUC, which is {RESOLVABLE_BASIS}. The single best combination is '
               f'the exception: '
               f'{"no other combination of the " + str(len(oof)) if TIED_WITH_BEST == 1 else str(TIED_WITH_BEST - 1) + " of the other " + str(len(oof) - 1)} '
               f'falls within that margin of it, so the leading combination is separated '
               f'from the rest even though most orderings below it are not. Rows are '
               f'ordered by ROC-AUC for readability and '
               f'models indistinguishable from the best in their representation are marked, '
               f'but the order among marked models is not a result. What the benchmark '
               f'supports is the comparison of representations and the identification of a '
               f'leading group, not a league table of eight classifiers.', False, False)])
    caption('Table 3', 'Random-split training out-of-fold comparative benchmark')
    table(_hdr, bench_rows(oof, 'Random'), widths=_BENCH_WIDTHS)
    legend(bench_legend())
    _sr = bench_rows(oof, 'Scaffold')
    if _sr:
        caption('Table 4', 'Scaffold-split training out-of-fold comparative benchmark')
        table(_hdr, _sr, widths=_BENCH_WIDTHS)
        # Which metrics may be compared across the two tables at all. Class composition
        # differs between the held-out partitions because scaffold allocation is blind to
        # class, and precision, F1, accuracy and PR-AUC all move with prevalence - the
        # PR-AUC baseline IS the prevalence. The earlier legend warned about accuracy and
        # F1 only, which became an omission when PR-AUC was added to these tables.
        _prev_note = ''
        try:
            _pv = splits.set_index('Split')
            _pr = float(_pv.loc['Random', 'Test active']) / float(_pv.loc['Random', 'Test N'])
            _ps = float(_pv.loc['Scaffold', 'Test active']) / float(_pv.loc['Scaffold', 'Test N'])
            _prev_note = (
                f'Held-out class composition differs between the splits ({f(_pr, 3)} Active '
                f'for the random partition against {f(_ps, 3)} for the scaffold partition), '
                f'because scaffold allocation is blind to class. Precision, F1, accuracy and '
                f'PR-AUC all depend on prevalence — the PR-AUC baseline is the '
                f'prevalence itself — so none of those four should be compared between '
                f'Tables 3 and 4. Recall, specificity, balanced accuracy and ROC-AUC are '
                f'prevalence-independent and are the metrics to compare across splits.')
        except Exception:
            _prev_note = ''
        legend(bench_legend('Abbreviations and the † mark as in Table 3. Scaffold groups '
                            'were preserved in outer, inner and final-search folds. '
                            + _prev_note))

H('Designated seven-descriptor Random Forest', 2)
if DESIGNATED_GAP is not None:
    _verb = ('exceeds' if DESIGNATED_GAP_REAL else 'falls within')
    rich([('The designated model is not the strongest in the benchmark, and the choice is '
           'deliberate. ', True, False),
          (f'The best out-of-fold discrimination came from {BEST_LABEL} at ROC-AUC '
           f'{f(BEST_ROC)}, against {f(DESIGNATED_ROC)} for the designated seven-descriptor '
           f'forest — a difference of {f(DESIGNATED_GAP)}, which {_verb} the '
           f'{f(RESOLVABLE)} margin this study treats as resolvable. We therefore do not '
           f'claim the two are equivalent: on discrimination alone the '
           f'{BEST_REP.lower()} forest is the better model.'
           + (' We designate the seven-descriptor forest regardless, for three reasons that '
              'concern what the model is for. First, the study’s interpretive claims '
              'rest on attributions over named physicochemical properties; Shapley values '
              'over a thousand fingerprint bits are not a chemically actionable explanation, '
              'and an uninterpretable model would make the interpretation section '
              'unsupportable rather than merely harder. Second, the applicability domain is '
              'defined as a bounding box in descriptor space, so domain membership is '
              'meaningful for the descriptor model and would require a different '
              'construction for a fingerprint model. Third, the screening workflow '
              'prioritises compounds by properties a medicinal chemist can act on. The cost '
              'of that choice is the discrimination difference stated above, and it is a '
              'cost rather than a tie.' if DESIGNATED_GAP_REAL else
              ' The difference is within the resolvable margin, so the choice carries no '
              'measurable discrimination cost; it is made for interpretability.'),
           False, False)])
_cmr = cm.get('Random', cm) if isinstance(cm, dict) else {}
_tp, _fn = int(_cmr.get('TP', 0)), int(_cmr.get('FN', 0))
_tn, _fp = int(_cmr.get('TN', 0)), int(_cmr.get('FP', 0))
P(f'The designated random-split forest achieved out-of-fold ROC-AUC {f(rand_oof["ROC-AUC"])} and '
  f'held-out ROC-AUC {f(rand_ho["ROC-AUC"])}, with held-out accuracy {f(rand_ho["Accuracy"])}, '
  f'Active-class precision {f(rand_ho["Active-class precision"])}, recall '
  f'{f(rand_ho["Active-class recall"])} and F1 {f(rand_ho["Active-class F1-score"])} (Table 5; '
  f'Figs. 5, 6). At the default 0.5 decision threshold it identified {_tp} of {_tp+_fn} Active '
  f'parents and {_tn} of {_tn+_fp} Inactive parents.'
  + (f' The separately fitted scaffold model achieved held-out ROC-AUC '
     f'{f(scaf_ho["ROC-AUC"])} with recall {f(scaf_ho["Active-class recall"])}.'
     if scaf_ho is not None else ''))

caption('Table 5', 'Seven-descriptor Random Forest performance on real compounds')
_r5 = [[str(r['Splitting strategy']), str(r['Evaluation type']),
        str(int(r['Real-compound evaluation N'])), f(r['Accuracy']),
        f(r['Active-class precision']), f(r['Active-class recall']),
        f(r['Active-class F1-score']), f(r['ROC-AUC'])] for _, r in rfperf.iterrows()]
table(['Split', 'Evaluation', 'N', 'Accuracy', 'Precision', 'Recall', 'F1', 'ROC-AUC'], _r5,
      widths=[0.9, 0.95, 0.6, 0.8, 0.8, 0.75, 0.7, 0.8])
legend('All class-specific metrics refer to Active = 1 at the default 0.5 threshold; Table 12 '
       'reports the threshold dependence. Random and scaffold models were fitted separately. The '
       'two held-out sets have different class compositions, so accuracy and F1 are not directly '
       'comparable between splits.')

H('Operating point and the sensitivity trade-off', 2)
if sweep is not None and len(sweep):
    _sw = sweep.copy()
    _tcol = 'Threshold' if 'Threshold' in _sw.columns else _sw.columns[0]
    P('Every metric above uses the classifier default of 0.5, which was not chosen for a screening '
      'application. Because the cut-off trades sensitivity against precision directly, the '
      'dependence is reported explicitly (Table 12; Fig. 12). Sensitivity is therefore largely a '
      'property of the operating point rather than a fixed deficiency of the model, and a '
      'prioritisation workflow should state and justify the threshold it uses.')
    caption('Table 12', 'Held-out threshold dependence for the designated Random Forest')
    _cols12 = [c for c in ['Accuracy', 'Active precision', 'Active recall', 'Active F1', 'FNR',
                           'Flagged N'] if c in _sw.columns]
    _r12 = [[f(r[_tcol], 2)] + [(f'{100*float(r[c]):.1f}%' if c == 'FNR' else
             (str(int(r[c])) if c == 'Flagged N' else f(r[c]))) for c in _cols12]
            for _, r in _sw.iterrows()]
    table(['Threshold'] + _cols12, _r12, widths=[0.9] + [5.6/len(_cols12)]*len(_cols12))
    legend('FNR false negative rate; Flagged N the number of held-out compounds predicted Active. '
           'Computed on the random held-out partition from the designated model. Lowering the '
           'threshold recovers active compounds at a precision cost that the table makes explicit.')

H('Primary performance estimate: repeated internal validation', 2)
if stability is not None and len(stability):
    # Numeric columns only. The repeated-validation export also carries the selected
    # hyperparameters and a checksum of each evaluation partition, both strings, which
    # must not be fed to a mean.
    _c13 = [c for c in stability.columns
            if c != 'Seed' and pd.api.types.is_numeric_dtype(stability[c])]
    _n13 = len(stability)
    _m, _s = stability['ROC-AUC'].mean(), stability['ROC-AUC'].std(ddof=1)
    # Nadeau-Bengio correction for dependent resampling: the repetitions share compounds,
    # so SD/sqrt(n) would understate the uncertainty of their mean.
    _overlap = 0.2 / 0.8
    _half = 1.96 * _s * np.sqrt(1.0 / _n13 + _overlap)
    _naive_half = 1.96 * _s / np.sqrt(_n13)
    _settings = (stability['Selected parameters'].nunique()
                 if 'Selected parameters' in stability.columns else None)
    _distinct = (stability['Test index sha256'].nunique()
                 if 'Test index sha256' in stability.columns else _n13)

    P(f'The designated model’s primary performance estimate comes from {_n13} repeated '
      f'stratified 80/20 partitions, each drawn afresh, with the hyperparameter search '
      f'carried out inside that repetition’s own training partition so that no '
      f'evaluation compound influences the configuration being scored. All {_distinct} '
      f'evaluation partitions are distinct. Mean ROC-AUC was {f(_m)} with a '
      f'standard deviation across repetitions of {f(_s)} (Table 13).')
    rich([('These repetitions are not independent experiments. ', True, False),
          (f'Any two 80/20 training partitions share roughly 80% of their compounds, so the '
           f'per-repetition estimates are positively correlated and the ordinary standard '
           f'error understates the uncertainty of their mean. Intervals are therefore '
           f'computed with the Nadeau–Bengio variance estimate for repeated random '
           f'train/test resampling [31], giving a 95% interval of {f(_m)} ± '
           f'{f(_half)} against {f(_naive_half)} under an independence assumption. The '
           f'corrected interval is {f(_half/_naive_half, 2)} times wider and is the one '
           f'quoted throughout. A consequence worth stating plainly: because the correction '
           f'retains a term that does not shrink with the number of repetitions, adding '
           f'repetitions improves the estimate of the spread but does not drive the '
           f'interval toward zero.', False, False)])
    P('This is repeated internal validation. It is not independent external validation, and '
      'it is not a demonstration of unbiased generalisation: every repetition resamples the '
      'same curated compound collection, so the interval describes variability across '
      'partitions of these data rather than sampling from the wider chemical space.')
    if _settings and _settings > 1:
        P(f'The grid search selected {_settings} distinct hyperparameter configurations '
          f'across the {_n13} repetitions. The designated configuration is therefore the '
          f'most frequently selected rather than a uniquely optimal one, and this '
          f'instability is itself a result: a single tuned configuration reported from one '
          f'partition would convey a stability these data do not support.')
    caption('Table 13',
            'Repeated internal validation of the designated model across fresh stratified partitions')
    _r13 = [['Mean'] + [f(stability[c].mean()) for c in _c13],
            ['Standard deviation'] + [f(stability[c].std(ddof=1)) for c in _c13],
            ['Minimum'] + [f(stability[c].min()) for c in _c13],
            ['Maximum'] + [f(stability[c].max()) for c in _c13]]
    table(['Statistic'] + _c13, _r13, widths=[1.3] + [5.2/len(_c13)]*len(_c13))
    legend(f'Computed over {_n13} stratified 80/20 partitions drawn with distinct seeds, the '
           f'designated model retuned and refitted within each repetition’s training rows. '
           f'The partition used for the single held-out evaluation reported elsewhere is '
           f'deliberately excluded, because it was examined during the exploratory comparison '
           f'of imbalance-handling strategies and is reported separately for that reason. '
           f'Standard deviations are the spread across repetitions; confidence intervals in '
           f'the text apply the dependence correction described above. The scaffold partition '
           f'is deterministic by construction and has no corresponding spread.')

H('Physicochemical interpretation', 2)
_mdi_s = mdi.set_index('RDKit Descriptor') if 'RDKit Descriptor' in mdi.columns else mdi
_shap_s = shapr.set_index('Descriptor') if 'Descriptor' in shapr.columns else shapr
_shap_col = [c for c in _shap_s.columns if 'SHAP' in c][0]
_top_mdi = _mdi_s['Mean Importance'].sort_values(ascending=False)
_top_shap = _shap_s[_shap_col].sort_values(ascending=False)
P(f'Impurity importance ranked {_top_mdi.index[0]} first, followed by {_top_mdi.index[1]} and '
  f'{_top_mdi.index[2]}. Shapley values ranked {_top_shap.index[0]} first, followed by '
  f'{_top_shap.index[1]} and {_top_shap.index[2]} (Table 6; Figs. 7, 8). Agreement on the leading '
  f'group does not remove the bias of impurity importance toward continuous predictors or establish '
  f'mechanistic importance.')
if boot is not None and len(boot):
    _bcol = [c for c in boot.columns if 'Bootstrap mean' in c]
    _lo = [c for c in boot.columns if '2.5' in c]
    _hi = [c for c in boot.columns if '97.5' in c]
    _tv = [c for c in boot.columns if 'Tree-variation' in c]
    if _bcol and _lo and _hi and _tv:
        _bw = (boot[_hi[0]] - boot[_lo[0]]).mean()
        _tw = (2 * boot[_tv[0]]).mean()
        P(f'Compound-level bootstrap intervals are substantially wider than the spread of importance '
          f'across the trees of a single forest: mean width {f(_bw, 4)} against {f(_tw, 4)}, a '
          f'factor of about {f(_bw/_tw, 1)}. The across-tree spread is reported as descriptive only, '
          f'and the bootstrap interval is the one that supports any inferential statement about '
          f'feature importance.')

caption('Table 6', 'Impurity importance, Shapley ranking and bootstrap intervals')
_idx = list(_top_shap.index)
_r6 = []
for d in _idx:
    row = [d, f(_mdi_s.loc[d, 'Mean Importance'], 4), f(_shap_s.loc[d, _shap_col], 4)]
    if boot is not None and len(boot):
        bs = boot.set_index('RDKit Descriptor') if 'RDKit Descriptor' in boot.columns else boot
        if d in bs.index and _lo and _hi:
            row.append(f'{f(bs.loc[d, _lo[0]], 4)}–{f(bs.loc[d, _hi[0]], 4)}')
        else:
            row.append('')
    _r6.append(row)
_h6 = ['Descriptor', 'Mean impurity importance', 'Mean |SHAP|']
if boot is not None and len(boot):
    _h6.append('Bootstrap 95% interval')
table(_h6, _r6, widths=[1.5, 1.8, 1.4, 1.8][:len(_h6)])
legend('Rows are ordered by mean absolute Shapley value, so the impurity column is not monotonic. '
       'Shapley magnitudes are in Active-probability units averaged over the held-out parents. The '
       'bootstrap interval resamples training compounds and is the appropriate interval for '
       'inference; the across-tree spread reported by the analysis is descriptive and narrower.')

H('Comparison with trivial baselines', 2)
if baselines is not None and len(baselines):
    _bl = baselines.copy()
    _nm = _bl.columns[0] if _bl.index.name is None and _bl.shape[1] > 1 else None
    P('A ROC-AUC near 0.84 is only meaningful relative to what simpler rules achieve on the same '
      'held-out compounds, particularly because MolLogP alone separates the classes appreciably. '
      'The designated forest is therefore compared against a majority-class predictor, MolLogP rank '
      'order and logistic regression on MolLogP alone (Table 14).')
    caption('Table 14', 'Designated model against trivial baselines on the held-out partition')
    _cols = [c for c in _bl.columns if c.lower() not in ('unnamed: 0',)]
    _labb = 'Baseline' if 'Baseline' in _bl.columns else None
    _cols = [c for c in _cols if c != _labb]
    _rows = []
    for idx, r in _bl.iterrows():
        lab = str(r[_labb]) if _labb else str(idx)
        _rows.append([lab] + [cellf(c, r[c])
                              for c in _cols])
    table(['Model'] + [str(c) for c in _cols], _rows,
          widths=[2.4] + [4.1/max(len(_cols),1)]*len(_cols))
    legend('Computed on the same held-out partition as Table 5. If the forest does not clearly '
           'exceed the single-descriptor baseline, the contribution of this work is the '
           'interpretable, provenance-tracked workflow rather than predictive performance.')

H('Probability calibration', 2)
if calmeta:
    _b, _bp = calmeta.get('brier'), calmeta.get('brier_prevalence_only')
    _bss = (1 - _b/_bp) if (_b and _bp) else None
    P(f'The screening ranks compounds by predicted probability and samples them in probability '
      f'bands, so the probabilities must carry meaning. The held-out Brier score was {f(_b, 4)} '
      f'against {f(_bp, 4)} for a prevalence-only forecast'
      + (f', a Brier skill score of {f(_bss, 3)}' if _bss is not None else '') +
      '. The reliability curve is shown in Additional file 1, Figure S2. Probabilities are not '
      'externally calibrated and should be read as a ranking score rather than a calibrated risk.')
if gran:
    _dp, _nt = gran.get('distinct_probabilities'), gran.get('n_trees')
    P(f'Probability resolution is adequate for ranking: the {_nt}-tree forest produced {_dp} '
      f'distinct probability values across the screened library, so the probability bands used for '
      f'illustrative sampling do not contain large blocks of exactly tied compounds.')

H('In silico profiling of benchmark compounds', 2)
if bench is not None and len(bench):
    _bn = bench.copy()
    _namecol = 'Name' if 'Name' in _bn.columns else _bn.columns[0]
    _act = _bn[_bn['Predicted_CD133_Activity_Label'] == 'Active'] if 'Predicted_CD133_Activity_Label' in _bn.columns else _bn
    P(f'Of the five literature comparators, {len(_act)} were predicted Active and '
      f'{len(_bn)-len(_act)} Inactive (Table 7). These are computational profiles, not newly '
      f'measured activity: the compounds have heterogeneous literature contexts, and parent '
      f'identities overlap the modelling collection, so this exercise is not independent validation.')
    caption('Table 7', 'Computational profiles of the five literature benchmark compounds')
    _c7 = [c for c in ['Predicted_CD133_Activity_Label', 'Predicted_Active_Probability',
                       'ExactMolWt', 'MolLogP', 'TPSA', 'Lipinski_Total_Violations']
           if c in _bn.columns]
    _hdr7 = {'Predicted_CD133_Activity_Label': 'Predicted class',
             'Predicted_Active_Probability': 'P(Active)', 'ExactMolWt': 'ExactMolWt (Da)',
             'MolLogP': 'MolLogP', 'TPSA': 'TPSA (Å²)',
             'Lipinski_Total_Violations': 'Ro5 violations'}
    _r7 = []
    for _, r in _bn.iterrows():
        row = [str(r[_namecol])]
        for c in _c7:
            v = r[c]
            row.append(str(v) if isinstance(v, str) else
                       (str(int(v)) if c == 'Lipinski_Total_Violations' else f(v)))
        _r7.append(row)
    table(['Compound'] + [_hdr7[c] for c in _c7], _r7,
          widths=[1.3] + [5.2/len(_c7)]*len(_c7))
    legend('Ro5 Lipinski rule of five. Probabilities are model outputs, not calibrated confidence '
           'in biological activity. Ordering is by descending probability then ascending violation '
           'count. This is a profiling exercise, not a validation set.')

H('Repurposing screening and applicability domain', 2)
_cm_rand = cm.get('Random', cm) if isinstance(cm, dict) else {}
if counts is not None and len(counts) and _cm_rand:
    _sc = counts['entries']
    _s_act, _s_tot = int(_sc.get('Active', 0)), int(_sc.sum())
    _htp, _hfp = int(_cm_rand.get('TP', 0)), int(_cm_rand.get('FP', 0))
    _hfn, _htn = int(_cm_rand.get('FN', 0)), int(_cm_rand.get('TN', 0))
    _hn = _htp + _hfp + _hfn + _htn
    if _s_tot and _hn:
        _flag_held = (_htp + _hfp) / _hn
        _true_held = (_htp + _hfn) / _hn
        rich([('The share of the library flagged Active should not be read as a prevalence '
               'estimate. ', True, False),
              (f'{pct(_s_act / _s_tot)} of screened entries were flagged at the 0.5 '
               f'threshold, against a true Active rate of {pct(_true_held)} in the held-out '
               f'assay compounds. Part of that difference is the operating point rather '
               f'than the library: on the held-out partition, where the true rate is known, '
               f'the same model and threshold flag {pct(_flag_held)}, because cost-sensitive '
               f'weighting shifts the boundary toward the minority class. The remaining '
               f'difference is consistent with the repurposing library being more '
               f'drug-like, and therefore more similar to the Active-labelled parents, than '
               f'the assay collection. Neither component licenses the inference that half '
               f'the library is active; the flagged set is a ranked prioritisation at a '
               f'stated cut-off.', False, False)])
_act_n = int(counts.loc['Active', 'entries']) if 'Active' in counts.index else 0
_ina_n = int(counts.loc['Inactive', 'entries']) if 'Inactive' in counts.index else 0
_tot_n = _act_n + _ina_n
P(f'Of {thousands(_tot_n)} curated repurposing entries, {_act_n} were predicted Active '
  f'({pct(_act_n/_tot_n)}) and {_ina_n} Inactive ({pct(_ina_n/_tot_n)}; Table 8). A seeded '
  f'probability-band sample is given in Table 9.')

caption('Table 8', 'Predicted classes in the curated repurposing subset')
table(['Predicted class', 'Entries', 'Percentage'],
      [[str(i), str(int(counts.loc[i, 'entries'])), f'{100*counts.loc[i,"entries"]/_tot_n:.1f}']
       for i in counts.index] + [['Total', str(_tot_n), '100.0']],
      widths=[2.4, 1.6, 1.6])
legend('Classes come from the prediction function of the designated Random Forest at the default '
       'threshold. Probability estimates are not externally calibrated.')

if sample is not None and len(sample):
    caption('Table 9', 'Seeded probability-band sample of predicted-active repurposing entries')
    _sc9 = [c for c in ['Name', 'Disease Area', 'Predicted_Active_Probability',
                        'Lipinski_Total_Violations'] if c in sample.columns]
    _r9 = []
    for n, (_, r) in enumerate(sample.iterrows(), 1):
        row = [str(n)]
        for c in _sc9:
            v = r[c]
            row.append(str(v) if isinstance(v, str) else
                       (str(int(v)) if c == 'Lipinski_Total_Violations' else f(v)))
        _r9.append(row)
    table(['Order'] + ['Compound' if c == 'Name' else
                       ('Library disease areas' if c == 'Disease Area' else
                        ('P(Active)' if 'Prob' in c else 'Ro5 violations')) for c in _sc9], _r9,
          widths=[0.6, 1.7, 2.4, 0.95, 0.85][:len(_sc9)+1])
    legend('A seeded stratified sample across probability bands, not a global top ranking. Disease '
           'areas are supplied library annotations, not verified indications or measured actions in '
           'glioblastoma. All sampled entries lie inside the descriptor-bounding applicability '
           'domain.')

_in_dom = int(adobs.shape[0])
P(f'All {thousands(_tot_n)} entries satisfied the training-derived seven-descriptor bounds '
  f'(Table 10). The observed library ranges were strictly interior to the training bounds for every '
  f'descriptor, which quantifies how permissive the envelope is: the domain did not identify any '
  f'out-of-domain entry, and a 100% pass rate should not be read as reassurance about predictive '
  f'reliability.')

caption('Table 10', 'Training-derived descriptor bounds and observed library ranges')
_r10 = []
for d in adb.index:
    # RotatableBonds, HBD, HBA and AromaticRings are integer counts; MolLogP, TPSA and
    # ExactMolWt are continuous, so the descriptor name decides the formatting.
    row = [str(d), cellf(d, adb.loc[d].iloc[0]), cellf(d, adb.loc[d].iloc[1])]
    if d in adobs.index:
        row += [cellf(d, adobs.loc[d, 'min']), cellf(d, adobs.loc[d, 'max'])]
    else:
        row += ['', '']
    _r10.append(row)
table(['Descriptor', 'Training minimum', 'Training maximum', 'Library minimum', 'Library maximum'],
      _r10, widths=[1.5, 1.3, 1.3, 1.3, 1.3])
legend('Bounds were computed from the real, unscaled random-training parents using both classes. '
       'Library minima and maxima are the observed values across the curated entries and are shown '
       'to indicate how much of the envelope the screened library occupies; they do not define the '
       'domain. TPSA is in Å² and ExactMolWt in Da; the remaining descriptors are counts.')

if disease is not None and len(disease):
    _mm = (multi or {}).get('multi_annotation_entries')
    P(f'Because library annotations permit multiple disease areas per entry, predicted-active '
      f'proportions are summarised by annotation group rather than as a partition (Table 11). '
      + (f'{_mm} entries carry more than one annotation, so the group counts do not sum to the '
         f'library total. ' if _mm else '') +
      'Any apparent concentration of a therapeutic area among predicted actives must be read '
      'against the composition of the source library rather than as a discovered preference.')
    caption('Table 11', 'Predicted-active proportions by disease-area annotation group')
    _labd = 'Annotation group' if 'Annotation group' in disease.columns else None
    _colsd = [c for c in disease.columns if c != _labd]
    _rd = []
    for idx, r in disease.iterrows():
        lab = str(r[_labd]) if _labd else str(idx)
        _rd.append([lab] + [str(int(r[c])) if float(r[c]).is_integer() else f(r[c], 1)
                            for c in _colsd])
    table(['Annotation group'] + [str(c) for c in _colsd], _rd,
          widths=[2.6] + [4.0/max(len(_colsd), 1)]*len(_colsd))
    legend('Groups are defined by substring matching on the supplied annotation and are not '
           'mutually exclusive, so they must not be read as a partition of the library. '
           'Percentages are within each group.')

if ad_pct is not None and len(ad_pct) > 1:
    _mm = ad_pct[ad_pct['Percentile trim (%)'] == 0].iloc[0]
    _tr = ad_pct[ad_pct['Percentile trim (%)'] > 0]
    _total = int(_mm['Inside domain'] + _mm['Outside'])
    rich([('The applicability domain as constructed does not discriminate, and the reason '
           'is measurable rather than a matter of opinion. ', True, False),
          (f'The box is anchored on the minimum and maximum of each descriptor across the '
           f'training parents, and those extremes are set by a few outlying compounds '
           f'rather than by the bulk of the collection. It therefore admits all {_total} '
           f'screened entries. Rebuilding the same box after discarding a small fraction of '
           f'each training tail changes the outcome immediately: a '
           f'{f(_tr["Percentile trim (%)"].iloc[0], 1)}% trim places '
           f'{int(_tr["Outside"].iloc[0])} entries outside the domain, and a '
           f'{f(_tr["Percentile trim (%)"].iloc[-1], 1)}% trim places '
           f'{int(_tr["Outside"].iloc[-1])} outside, or '
           f'{f(_tr["Outside (%)"].iloc[-1], 1)}% of the library (Table 14). Domain '
           f'membership here is thus governed by the choice of construction rather than by '
           f'the chemistry, and no screened compound should be treated as '
           f'domain-validated on the minimum-maximum criterion alone. A leverage or '
           f'distance-to-model domain would be the stronger construction and is the '
           f'recommended next step for anyone building on this screen.', False, False)])
    caption('Table 14',
            'Applicability-domain membership under alternative bounding-box constructions')
    table(['Trim (%)', 'Lower bound', 'Upper bound', 'Inside', 'Outside', 'Outside (%)'],
          [[f(r['Percentile trim (%)'], 1), str(r['Lower']), str(r['Upper']),
            str(int(r['Inside domain'])), str(int(r['Outside'])), f(r['Outside (%)'], 1)]
           for _, r in ad_pct.iterrows()],
          widths=[0.85, 1.05, 1.05, 0.85, 0.85, 1.0])
    legend('Each row rebuilds the descriptor bounding box after discarding the stated '
           'percentage from each tail of every training descriptor, then counts screened '
           'library entries falling outside it. The first row is the construction used in '
           'the main analysis. This is a diagnostic of the domain definition; it does not '
           'alter the designated model, the benchmark or any reported prediction.')

H('Analogue similarity between held-out and training compounds', 2)
if simil is not None and len(simil):
    P('The difference between the random and scaffold results is driven by chemical similarity '
      'rather than by difficulty alone. Nearest-neighbour Tanimoto similarity between each held-out '
      'compound and the training set quantifies this (Table 15), and the random split contains '
      'markedly more close analogues on both sides of the partition.')
    caption('Table 15', 'Nearest-neighbour similarity between held-out and training compounds')
    _cs = [c for c in simil.columns if c != 'Split']
    _rs = [[str(r['Split'])] + [cellf(c, r[c])
                                for c in _cs] for _, r in simil.iterrows()]
    table(['Split'] + [str(c) for c in _cs], _rs, widths=[1.1] + [5.4/len(_cs)]*len(_cs))
    legend('Maximum ECFP4 Tanimoto similarity of each held-out compound to any training compound. '
           'The higher random-split similarity is the mechanism behind its higher ROC-AUC, so the '
           'random estimate is optimistically biased relative to prospective use.')

if overlap is not None and len(overlap):
    _ob = overlap.set_index('Collections') if 'Collections' in overlap.columns else overlap
    try:
        _tb = int(_ob.loc['Training / Broad'].iloc[0])
        P(f'An identity audit found {_tb} parent keys shared between the repurposing subset and the '
          f'modelling collection, so the screening is not an independent unseen-compound test.')
    except Exception:
        pass

# ============================== DISCUSSION ==============================
H('Discussion', 1)

H('Scope and principal findings', 2)
P('This work characterises bulk physicochemical patterns in a pooled phenotypic screening dataset '
  'associated with CD133⁺ neurosphere research, under a protocol in which preprocessing is '
  'contained inside training folds, every estimator is tuned under the same objective, and every '
  'reported number is emitted by the analysis rather than transcribed. The distinction between '
  'phenotypic activity and molecular target engagement is central: loss of viability can arise from '
  'many mechanisms unrelated to CD133, and the retained pooled-panel labels, including astrocyte '
  'records, prevent any claim of GSC-specific or CD133-dependent selectivity. The property patterns '
  'are hypotheses for testing in defined cell systems, not evidence of a CD133 inhibitor '
  'pharmacophore.')

H('Sensitivity is an operating-point choice, not a fixed deficiency', 2)
P('A false negative rate near one third at the default threshold would be a serious limitation for '
  'a prioritisation tool if it were immovable. It is not. The threshold analysis shows that '
  'lowering the cut-off recovers a substantial share of the missed actives for a modest precision '
  'cost, and the precision–recall curve makes the whole trade-off visible. The appropriate '
  'framing for a screening application is therefore a stated operating point with its justification '
  'and consequences, not the classification default accompanied by a complaint about sensitivity. '
  'Investigators applying this framework should set the threshold from the cost of a missed active '
  'relative to a wasted assay well in their own setting.')

H('What the comparisons can and cannot distinguish', 2)
P('Repeated random partitions show that held-out ROC-AUC varies appreciably from split to split. '
  f'Differences smaller than {f(RESOLVABLE)}, which is {RESOLVABLE_BASIS}, cannot be '
  f'attributed to the models, and {RESOLVE_UNRESOLVED} of {RESOLVE_TOTAL} adjacent pairs in '
  f'the benchmark tables fall inside that band. A single threshold is used throughout this '
  f'paper, so the tables, the Results and this discussion all mean the same thing by a '
  f'distinguishable difference. This '
  'analysis reports the spread and refrains from ranking claims the data cannot support. A related '
  'point concerns tuning parity: an earlier version of this comparison tuned four estimators and '
  'left four at library defaults, including a depth-limited decision tree, which measures tuning '
  'effort rather than algorithm behaviour. All estimators except the deliberately untuned linear '
  'baseline now receive the same search protocol, and the present tables should not be compared '
  'with that earlier formulation.')

H('Random and scaffold validation measure different things', 2)
P('Scaffold evaluation reduced discrimination relative to the random split. The mechanism is '
  'measurable rather than inferred: a substantially larger fraction of random held-out compounds '
  'have a close training analogue than scaffold held-out compounds. Close analogues on both sides '
  'of a random partition inflate its apparent performance, so the random estimate is optimistically '
  'biased and the scaffold estimate is the one that reflects prospective application to new '
  'chemotypes. The scaffold design is deliberately demanding in a further respect: greedy '
  'descending-size allocation places the largest scaffold classes, including the entire acyclic '
  'group, in training, so the test set consists of small and singleton scaffolds and no acyclic '
  'compound is ever evaluated. This is a worst-case transfer setting and should be described as '
  'such rather than as a neutral partition.')

H('Interpretation and its limits', 2)
P('Lipophilicity, polar surface area and molecular size rank highly under both attribution methods, '
  'and Shapley values supply the directional information that impurity importance lacks. '
  'These attributions explain the fitted model’s predictions and nothing more: they '
  'describe how this forest responds to these descriptors on these compounds, not how the '
  'descriptors act on CD133⁺ cells, and they are not evidence of a causal or biological '
  'mechanism. Three '
  'cautions apply. The descriptors are strongly correlated, so contributions cannot be read as '
  'independent physical determinants. Impurity importance is biased toward continuous predictors, '
  'and an interval around a biased estimator does not remove the bias. Finally, the across-tree '
  'spread of importance in a single forest is not a confidence interval and is several times '
  'narrower than the compound-level bootstrap; only the latter supports inference. Any apparent '
  'concentration of central nervous system compounds among predicted actives reflects the '
  'composition of the screening library and does not demonstrate that the model learned transport '
  'biology, since it was trained on assay outcomes rather than permeability measurements [10, 11].')

H('Screening priorities and the applicability domain', 2)
if DOMAIN_VACUOUS:
    rich([('The applicability domain does not constrain this library, and that is a '
           'structural fact rather than a coincidence. ', True, False),
          ((f'The training descriptor envelope contains the screened library’s observed '
            f'range on every one of the seven descriptors' +
            (f' — molecular mass, for instance, spans {f(DOMAIN_WIDEST[0], 1)} to '
             f'{f(DOMAIN_WIDEST[1], 1)} Da in training against {f(DOMAIN_WIDEST[2], 1)} to '
             f'{f(DOMAIN_WIDEST[3], 1)} Da in the library' if DOMAIN_WIDEST else '') +
            '. A marginal bounding box therefore admits every compound by construction, so '
            'the reported domain status provides no discrimination here and must not be read '
            'as a safeguard that was tested and passed. It is reported because the bounds '
            'themselves are informative about training coverage, not because the check '
            'filtered anything. A leverage or distance-to-model domain, which can detect '
            'sparse interior regions and descriptor correlations that a marginal box cannot, '
            'is the appropriate construction for prospective screening and is the clearest '
            'methodological improvement available to this workflow.'), False, False)])

P('The repurposing predictions provide a reproducible set of computational priorities with '
  'documented identities, exclusions, provenance and range-based domain status. Two limits bound '
  'their interpretation. The domain is a marginal bounding box: it cannot see descriptor '
  'correlations or sparse regions inside the envelope, which is why every screened compound passes, '
  'and a leverage or distance-to-model criterion would be more informative. And a substantial '
  'number of screened compounds already appear in the modelling collection, so the exercise is not '
  'external validation; predictions restricted to the unseen remainder would be the cleaner '
  'headline. Subsequent prioritisation requires testing in defined neurosphere and comparator '
  'systems, followed by mechanism-specific and exposure studies as warranted.')

H('Limitations', 2)
if CONFLICT_PCT:
    rich([('Label noise bounds what any model here can achieve. ', True, False),
          (f'{thousands(N_CONFLICT)} of the {thousands(N_PARENTS)} retained parent '
           f'groups — {f(CONFLICT_PCT, 1)}% — carried conflicting outcomes across '
           f'their source records, and these were resolved by retaining the first source '
           f'label. For that share of the data the assigned label is a function of source '
           f'ordering rather than of a reconciled experimental result, so a model that '
           f'predicted the underlying biology perfectly would still disagree with some of '
           f'these labels. Discrimination near the values reported here should therefore be '
           f'read against an unknown but non-trivial ceiling imposed by the labels, not as '
           f'the limit of what the descriptors can express. Quantifying that ceiling would '
           f'require refitting under alternative conflict-resolution rules, which we have '
           f'not done; it is the most informative single extension to this analysis.',
           False, False)])

rich([('Biological endpoint and pooling. ', True, False),
      ('The assay is phenotypic and cannot distinguish CD133 binding from other cytotoxic '
       'mechanisms. Multiple panels including astrocytes were pooled without cell-specific '
       'modelling, and keep-first deduplication retained source-order outcomes despite conflicting '
       'labels in a substantial number of parent groups. The procedure is reproducible but '
       'sensitive to source order and establishes neither selectivity nor a consensus response.',
       False, False)])
rich([('Representation and structural uncertainty. ', True, False),
      ((f'The designated model is not the best-discriminating combination: the '
        f'{BEST_REP.lower()} Random Forest scored {f(BEST_ROC)} against {f(DESIGNATED_ROC)}, '
        f'a difference larger than this study’s resolvable margin. That is a real cost '
        f'of prioritising interpretability, and a reader whose objective is predictive '
        f'performance alone should prefer the higher-dimensional model. '
        if DESIGNATED_GAP_REAL else '') +
       'Seven descriptors summarise bulk properties rather than complete chemical space, and '
       'fingerprint and hybrid representations add connectivity without providing a stereochemical '
       'or three-dimensional pharmacophore description. Enhanced identity preservation prevented '
       'unsupported merges, but a number of retained library entries still carry unresolved '
       'structural-annotation guards. Passing curation does not establish experimentally verified '
       'chemical identity.', False, False)])
rich([('Imbalance handling. ', True, False),
      ('Cost-sensitive class weighting is the designated framework and oversampling is '
       'reported alongside it, so the choice rests on a measured comparison. Two limits '
       'remain. The comparison fixed hyperparameters at values tuned under oversampling, so '
       'it does not exclude the possibility that a search conducted under class weighting '
       'would favour different settings. And k-nearest neighbours admits no class weighting, '
       'so that estimator alone is fitted unweighted and is not directly comparable to the '
       'others within a table.', False, False)])
rich([('Validation. ', True, False),
      ('One random and one scaffold holdout underlie the main tables; repeated-split variability is '
       'reported for the designated model but not for every benchmark combination, and no paired '
       'significance test is performed. Hyperparameter ranges remain finite.', False, False)])
rich([('Calibration and external evidence. ', True, False),
      ('Probabilities are not externally calibrated and should be treated as a ranking score. '
       'Library disease annotations are not validated indications, and rule-of-five counts are not '
       'exposure measurements. No new biological experiments were performed, so every prioritisation '
       'remains a hypothesis requiring prospective evaluation.', False, False)])

# ============================== CONCLUSIONS ==============================
H('Conclusions', 1)
_concl_scaf = (f' and {f(scaf_ho["ROC-AUC"])} on the scaffold partition, with the difference '
               f'traceable to measured analogue similarity rather than to difficulty alone'
               if scaf_ho is not None else '')
P(f'This framework combines reproducible structure curation, representation benchmarking under a '
  f'single tuning protocol, fold-contained preprocessing, scaffold validation and Shapley '
  f'interpretation for phenotypic screening data associated with CD133⁺ glioblastoma stem cell '
  f'research. The designated seven-descriptor Random Forest achieved held-out ROC-AUC '
  f'{f(rand_ho["ROC-AUC"])} on the random partition{_concl_scaf}. Its explanations emphasised lipophilicity, polar surface area and molecular '
  f'size as model-associated properties, with compound-level bootstrap intervals reported in place '
  f'of across-tree spread.')
P('Profiling of literature comparators and a repurposing library supplied computational hypotheses '
  'with provenance and descriptor-range assessment. The pooled assay construction, label '
  'disagreements, incomplete structural annotations, permissive applicability domain, collection '
  'overlap and absence of new biological experiments bound the interpretation. Sensitivity is best '
  'understood as an operating-point choice rather than a fixed property of the model. The results '
  'characterise physicochemical associations and support follow-up prioritisation; they do not '
  'demonstrate CD133 binding, selective GSC activity, blood-brain barrier penetration or '
  'therapeutic efficacy.')

# ============================== ABBREVIATIONS ==============================
H('List of abbreviations', 1)
for a, b in [('AD', 'Applicability domain'), ('BBB', 'Blood-brain barrier'),
             ('CNS', 'Central nervous system'),
             ('ECFP4', 'Extended-connectivity fingerprint, radius 2'),
             ('ExactMolWt', 'Exact molecular weight'), ('FNR', 'False negative rate'),
             ('GBM', 'Glioblastoma'), ('GSC', 'Glioblastoma stem cell'),
             ('HBA', 'Hydrogen-bond acceptors'), ('HBD', 'Hydrogen-bond donors'),
             ('MDI', 'Mean decrease in impurity'), ('ML', 'Machine learning'),
             ('MolLogP', 'Calculated octanol-water partition coefficient'),
             ('OOF', 'Out-of-fold'), ('RF', 'Random Forest'),
             ('ROC-AUC', 'Area under the receiver operating characteristic curve'),
             ('Ro5', 'Lipinski rule of five'), ('SHAP', 'Shapley additive explanations'),
             ('SMOTE', 'Synthetic Minority Over-sampling Technique'),
             ('SVM', 'Support vector machine'),
             ('TPSA', 'Topological polar surface area')]:
    rich([(a + ': ', True, False), (b, False, False)], after=0)

# ============================== DECLARATIONS ==============================
H('Declarations', 1)
H('Ethics approval and consent to participate', 2)
P('Not applicable. This is a computational study of publicly available bioassay and compound-library '
  'records. No human participants, human tissue or animals were involved.')
H('Consent for publication', 2)
P('Not applicable.')
H('Availability of data and materials', 2)
P('All data and code required to reproduce the conclusions are openly available without '
  'registration, login or acceptance of licence terms other than those stated below.')
P('Source bioassay records are available from PubChem BioAssay AID 1345199 [12] and compound-library '
  'records from the Broad Institute Drug Repurposing Hub [18]. The consolidated analysis notebook, '
  'curated datasets, per-combination checkpoints, machine-readable results export, figure files and '
  'curation provenance are available in the Zenodo repository, [INSERT ZENODO DOI AND https:// '
  'HYPERLINK]. No new experimental dataset was generated.')
for line in ['Project name: [INSERT PROJECT NAME]',
             'Project home page: [INSERT https:// GITHUB URL]',
             'Archived version: [INSERT ZENODO DOI]',
             'Operating system(s): Platform independent',
             'Programming language: Python 3',
             'Other requirements: ' + ', '.join(f'{k} {v}' for k, v in (versions or {}).items()),
             'License: MIT License (source code); Creative Commons Attribution 4.0 International '
             '(curated data and documentation)',
             'Any restrictions to use by non-academics: None']:
    P(line)
H('Competing interests', 2)
P('The authors declare that they have no financial or non-financial competing interests.')
H('Funding', 2)
P('This research was supported in part by the Howard–Hopkins Comprehensive Partnership to '
  'Advance Cancer Health (National Cancer Institute award 5U54CA295337-03). The funder had no role '
  'in the conceptualisation or design of the study, data collection, analysis, the decision to '
  'publish, or preparation of the manuscript.')
H('Authors’ contributions', 2)
P('EEA conceived and supervised the study, designed the machine learning and validation framework, '
  'and verified the computational results. BW curated the datasets, implemented the '
  'structure-curation and modelling notebook, and generated the figures and tables. EEA and BW '
  'interpreted the results and drafted the manuscript. Both authors critically revised the '
  'manuscript and read and approved the final version.')
H('Acknowledgements', 2)
P('The authors thank colleagues in the Department of Pharmaceutical Sciences, College of Pharmacy, '
  'Howard University, for helpful discussion. [CONFIRM OR REMOVE before submission; obtain '
  'permission from any named individual.]')

# ============================== REFERENCES ==============================
H('References', 1)
REFS = [
 'Singh SK, Hawkins C, Clarke ID, Squire JA, Bayani J, Hide T, Henkelman RM, Cusimano MD, Dirks PB (2004) Identification of human brain tumour initiating cells. Nature 432(7015):396-401. doi:10.1038/nature03128',
 'Lathia JD, Mack SC, Mulkearns-Hubert EE, Valentim CLL, Rich JN (2015) Cancer stem cells in glioblastoma. Genes Dev 29(12):1203-1217. doi:10.1101/gad.261982.115',
 'Moreno-Londono AP, Robles-Flores M (2024) Functional roles of CD133: more than stemness associated factor regulated by the microenvironment. Stem Cell Rev Rep 20(1):25-51. doi:10.1007/s12015-023-10647-6',
 'Kolluri S, Lin J, Liu R, Zhang Y, Zhang W (2022) Machine learning and artificial intelligence in pharmaceutical research and development: a review. AAPS J 24(1):19. doi:10.1208/s12248-021-00644-3',
 'Sarkar C, Das B, Rawat VS, Wahlang JB, Nongpiur A, Tiewsoh I, Lyngdoh NM, Das D, Bidarolli M, Sony HT (2023) Artificial intelligence and machine learning technology driven modern drug discovery and development. Int J Mol Sci 24(3):2026. doi:10.3390/ijms24032026',
 'Yang Y, Liu Z, Wang Z, Fu X, Li Z, Li J, Xu Z, Cen B (2025) Large-scale bulk and single-cell RNA sequencing combined with machine learning reveals glioblastoma-associated neutrophil heterogeneity and establishes a VEGFA+ neutrophil prognostic model. Biol Direct 20(1):45. doi:10.1186/s13062-025-00640-z',
 'Venugopal C, Hallett R, Vora P, Manoranjan B, Mahendram S, Qazi MA, McFarlane N, Subapanditha M, Nolte SM, Singh M, Bakhshinyan D, Garg N, Vijayakumar T, Lach B, Provias JP, Reddy K, Murty NK, Doble BW, Bhatia M, Singh SK (2015) Pyrvinium targets CD133 in human glioblastoma brain tumor-initiating cells. Clin Cancer Res 21(23):5324-5337. doi:10.1158/1078-0432.CCR-14-3147',
 'Hanson G, Adams J, Kepgang DIB, Zondagh LS, Tem Bueh L, Asante A, Shirolkar SA, Kisaakye M, Bondarwad H, Awe OI (2024) Machine learning and molecular docking prediction of potential inhibitors against dengue virus. Front Chem 12:1510029. doi:10.3389/fchem.2024.1510029',
 'Raju B, Narendra G, Verma H, Kumar M, Sapra B, Kaur G, Jain SK, Silakari O (2022) Machine learning enabled structure-based drug repurposing approach to identify potential CYP1B1 inhibitors. ACS Omega 7(36):31999-32013. doi:10.1021/acsomega.2c02983',
 'Cornelissen FMG, Markert G, Deutsch G, Antonara M, Faaij N, Bartelink I, Noske D, Vandertop WP, Bender A, Westerman BA (2023) Explaining blood-brain barrier permeability of small molecules by integrated analysis of different transport mechanisms. J Med Chem 66(11):7253-7267. doi:10.1021/acs.jmedchem.2c01824',
 'Dehnbostel FO, Dixit VA, Preissner R, Banerjee P (2024) Non-animal models for blood-brain barrier permeability evaluation of drug-like compounds. Sci Rep 14(1):8908. doi:10.1038/s41598-024-59734-9',
 'National Center for Biotechnology Information. PubChem BioAssay record for AID 1345199: drug repurposing screens with cells derived from glioblastoma tumor samples. https://pubchem.ncbi.nlm.nih.gov/bioassay/1345199. Accessed 23 May 2026',
 'Rogers D, Hahn M (2010) Extended-connectivity fingerprints. J Chem Inf Model 50(5):742-754. doi:10.1021/ci100050t',
 'Chen T, Yi L, Li F, Hu R, Hu S, Yin Y, Lan C, Li Z, Fu C, Cao L, Chen Z, Xian J, Feng H (2015) Salinomycin inhibits the tumor growth of glioma stem cells by selectively suppressing glioma-initiating cells. Mol Med Rep 11(4):2407-2412. doi:10.3892/mmr.2014.3027',
 'Wei Y, Jiang J, Liang Z (2020) Screening method of small molecule compounds targeting CD133 and its application in pharmacy. Chinese Patent Application Publication No. CN111721932A. https://patents.google.com/patent/CN111721932A/en. Accessed 23 May 2026',
 'Jezierzanski M, Nafalska N, Stopyra M, Furgol T, Miciak M, Kabut J, Gisterek-Grocholska I (2024) Temozolomide (TMZ) in the treatment of glioblastoma multiforme: a literature review and clinical outcomes. Curr Oncol 31(7):3994-4002. doi:10.3390/curroncol31070296',
 'Wurth R, Pattarozzi A, Gatti M, Bajetto A, Corsaro A, Parodi A, Sirito R, Massollo M, Marini C, Zona G, Fenoglio D, Sambuceti G, Filaci G, Daga A, Barbieri F, Florio T (2013) Metformin selectively affects human glioblastoma tumor-initiating cell viability: a role for metformin-induced inhibition of Akt. Cell Cycle 12(1):145-156. doi:10.4161/cc.23050',
 'Corsello SM, Bittker JA, Liu Z, Gould J, McCarren P, Hirschman JE, Johnston SE, Vrcic A, Wong B, Khan M, Asiedu J, Narayan R, Mader CC, Subramanian A, Golub TR (2017) The Drug Repurposing Hub: a next-generation drug library and information resource. Nat Med 23(4):405-408. doi:10.1038/nm.4306',
 'Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel M, Prettenhofer P, Weiss R, Dubourg V, Vanderplas J, Passos A, Cournapeau D, Brucher M, Perrot M, Duchesnay E (2011) Scikit-learn: machine learning in Python. J Mach Learn Res 12:2825-2830',
 'Lemaitre G, Nogueira F, Aridas CK (2017) Imbalanced-learn: a Python toolbox to tackle the curse of imbalanced datasets in machine learning. J Mach Learn Res 18(17):1-5',
 'Chen T, Guestrin C (2016) XGBoost: a scalable tree boosting system. In: Proceedings of the 22nd ACM SIGKDD international conference on knowledge discovery and data mining, San Francisco, August 2016. ACM, New York, pp 785-794. doi:10.1145/2939672.2939785',
 'Landrum G, Tosco P, Kelley B, Rodriguez R, Cosgrove D, Vianello R, Gedeck P, Jones G, Kawashima E, Nealschneider D, Dalke A, Swain M, Cole B, Turk S, Savelev A, Maeder N, Lehtivarjo J (2026) rdkit/rdkit. Zenodo. doi:10.5281/zenodo.18797641',
 'Lundberg SM, Lee S-I (2017) A unified approach to interpreting model predictions. In: Guyon I, von Luxburg U, Bengio S, Wallach H, Fergus R, Vishwanathan S, Garnett R (eds) Advances in neural information processing systems, vol 30. Curran Associates, Red Hook, pp 4765-4774',
 'Bento AP, Hersey A, Felix E, Landrum G, Gaulton A, Atkinson F, Bellis LJ, De Veij M, Leach AR (2020) An open source chemical structure curation pipeline using RDKit. J Cheminform 12:51. doi:10.1186/s13321-020-00456-1',
 'Lipinski CA, Lombardo F, Dominy BW, Feeney PJ (2001) Experimental and computational approaches to estimate solubility and permeability in drug discovery and development settings. Adv Drug Deliv Rev 46(1-3):3-26. doi:10.1016/S0169-409X(00)00129-0',
 'Bemis GW, Murcko MA (1996) The properties of known drugs. 1. Molecular frameworks. J Med Chem 39(15):2887-2893. doi:10.1021/jm9602928',
 'Martin EJ, Polyakov VR, Tian L, Perez RC (2017) Profile-QSAR 2.0: kinase virtual screening accuracy comparable to four-concentration IC50s for realistically novel compounds. J Chem Inf Model 57(8):2077-2088. doi:10.1021/acs.jcim.7b00166',
 'Chawla NV, Bowyer KW, Hall LO, Kegelmeyer WP (2002) SMOTE: synthetic minority over-sampling technique. J Artif Intell Res 16:321-357. doi:10.1613/jair.953',
 'Strobl C, Boulesteix A-L, Zeileis A, Hothorn T (2007) Bias in random forest variable importance measures: illustrations, sources and a solution. BMC Bioinformatics 8:25. doi:10.1186/1471-2105-8-25',
 'Lundberg SM, Erion G, Chen H, DeGrave A, Prutkin JM, Nair B, Katz R, Himmelfarb J, Bansal N, Lee S-I (2020) From local explanations to global understanding with explainable AI for trees. Nat Mach Intell 2(1):56-67. doi:10.1038/s42256-019-0138-9',
 'Benet LZ, Hosey CM, Ursu O, Oprea TI (2016) BDDCS, the Rule of 5 and drugability. Adv Drug Deliv Rev 101:89-98. doi:10.1016/j.addr.2016.05.007',
 'Sahigara F, Mansouri K, Ballabio D, Mauri A, Consonni V, Todeschini R (2012) Comparison of different approaches to define the applicability domain of QSAR models. Molecules 17(5):4791-4810. doi:10.3390/molecules17054791',
]
for i, r in enumerate(REFS, 1):
    P(f'{i}. {r}', after=3)

# ============================== FIGURE LEGENDS ==============================
H('Figure legends', 1)
FIGS = [
 ('Fig. 1', 'Executed analytical workflow for curation, benchmarking, interpretation and screening',
  'Out-of-fold denotes predictions on real training compounds. Preprocessing was fitted within each '
  'training fold, with class weights derived inside each fold; held-out compounds were excluded '
  'from all fitting. The comparative benchmark and the designated seven-descriptor Random Forest '
  'used for interpretation and screening are shown as separate branches.'),
 ('Fig. 2', 'Topological polar surface area distribution by retained assay class',
  'Kernel density estimates for the curated real-compound dataset. Class 0 is Inactive and class 1 '
  'is Active. Distributions overlap substantially, so no single-property activity threshold is '
  'implied. Computed on the full curated dataset, including compounds that later form the held-out '
  'sets.'),
 ('Fig. 3', 'Pearson correlations among the seven descriptors and encoded activity outcome',
  'Computed on the curated assay dataset. Strong associations among polarity, hydrogen bonding and '
  'size should be considered when interpreting feature contributions, because correlated '
  'descriptors share predictive information.'),
 ('Fig. 4', 'Out-of-fold ROC curves across molecular representations and splitting strategies',
  'Curves use saved real-compound out-of-fold labels and probabilities under random and scaffold '
  'splitting.'),
 ('Fig. 5', 'Seven-descriptor Random Forest ROC curves for out-of-fold and held-out evaluation',
  'Curves are shown for each splitting strategy. The random and scaffold curves concern separately '
  'fitted forests and refer to held-out sets with different class compositions.'),
 ('Fig. 6', 'Held-out confusion matrices for the seven-descriptor Random Forest',
  'Counts and row-normalised percentages at the default 0.5 decision threshold. False negatives '
  'occupy the lower-left cells; Table 12 reports how these counts change with the threshold.'),
 ('Fig. 7', 'Mean impurity importance in the designated Random Forest',
  'Bars show mean decrease in impurity. Whiskers show the descriptive spread across the trees of '
  'the fitted forest, which is not a confidence interval; the compound-level bootstrap intervals in '
  'Table 6 are the appropriate interval for inference.'),
 ('Fig. 8', 'Held-out SHAP beeswarm summary for the designated Random Forest',
  'Shapley additive explanations for Active = 1 across the real held-out parents. Positive values '
  'increase the modelled Active probability relative to the training background; colour represents '
  'feature value.'),
 ('Fig. 9', 'SHAP dependence plot for MolLogP in held-out parents',
  'The vertical axis gives the contribution of the feature to Active probability relative to the '
  'training background. Descriptor values are shown in original units.'),
 ('Fig. 10', 'SHAP dependence plot for topological polar surface area',
  'The vertical axis gives the contribution of the feature to Active probability relative to the '
  'training background. Descriptor values are shown in original units (Å²).'),
 ('Fig. 11', 'SHAP dependence plot for exact molecular weight',
  'The vertical axis gives the contribution of the feature to Active probability relative to the '
  'training background. Descriptor values are shown in original units (Da).'),
 ('Fig. 12', 'Held-out precision–recall curve for the designated Random Forest',
  'The dashed line marks the prevalence baseline. The curve shows the full sensitivity–'
  'precision trade-off from which an operating point should be chosen; Table 12 tabulates '
  'representative thresholds.'),
]
for lab, title, leg in FIGS:
    caption(lab, title)
    legend(leg)

# ============================== ADDITIONAL FILES ==============================
H('Additional files', 1)
rich([('Additional file 1. ', True, False),
      ('Format: .pdf. Title: Supplementary tables and figures. Description: Table S1, the '
       'hyperparameter settings selected by the training-only search for all 48 '
       'model-representation-split combinations, with the number of distinct settings chosen '
       'across the five outer folds of each; Tables S2 and S3, held-out comparative benchmarks '
       'for the random and scaffold splits; Table S4, accuracy for all 48 combinations, which '
       'is omitted from the primary tables; Figure S1, pairwise descriptor distributions by '
       'retained activity label; Figure S2, held-out reliability curve for the designated model.',
       False, False)])
rich([('Additional file 2. ', True, False),
      ('Format: .csv. Title: Entry-level repurposing screening predictions. Description: curated '
       'identities, seven descriptors, Active probabilities, predicted classes, rule-of-five '
       'violation counts, applicability-domain status and source annotations for every curated '
       'library entry.', False, False)])
rich([('Additional file 3. ', True, False),
      ('Format: .zip. Title: Machine-readable results export. Description: the complete set of '
       'files from which every table and quantitative statement in this manuscript was '
       'generated, together with the execution manifest recording software versions, dataset '
       'checksums, random seeds and per-chunk execution provenance, the complete execution '
       'log including the RDKit curation messages, and the figure manifests. The fitted per-combination model checkpoints are not included '
       'here because they exceed the additional-file size limit; they are archived with the '
       'code (see Availability of data and materials), where a verification script reloads them '
       'and reproduces their recorded predictions.', False, False)])

# ============================== SAVE + CHECK ==============================
doc.save(OUT)
print(f'\nWrote {OUT}')

# compliance self-check
import docx as _d
_chk = _d.Document(OUT)
_txt = '\n'.join(p.text for p in _chk.paragraphs)
_abs = _txt.split('Abstract', 1)[1].split('Keywords', 1)[0] if 'Abstract' in _txt else ''
print('--- compliance ---')
print(f'  abstract words (incl. headings): {len(_abs.split())}  (limit 350)')
print(f'  "Scientific Contribution" present: {"Scientific Contribution" in _abs}')
_sc = _abs.split('Scientific Contribution')[1].split('Methods')[0] if 'Scientific Contribution' in _abs else ''
print(f'  Scientific Contribution sentences: {_sc.count(".")}  (max 3)')
_kw = _txt.split('Keywords')[1].split('\n')[0] if 'Keywords' in _txt else ''
_kwn = len([k for k in _kw.split('·') if k.strip()])
print(f'  keywords: {_kwn}  (3-10)')
for h in ['Ethics approval and consent to participate', 'Consent for publication',
          'Availability of data and materials', 'Competing interests', 'Funding',
          'Authors’ contributions', 'Acknowledgements', 'List of abbreviations']:
    print(f'  declaration present: {h}: {h in _txt}')
print(f'  tables in document: {len(_chk.tables)}')
print(f'  paragraphs: {len(_chk.paragraphs)}')
