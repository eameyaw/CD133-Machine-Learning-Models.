#!/usr/bin/env bash
# Production benchmark launcher.
#
# The exit status of the Python process is what decides whether this run counts, so this
# script is written so that status cannot be lost. An earlier run of this project was
# reported as "exit code 0" when the analysis had in fact died with a NameError, because
# the launch command ended with `echo "EXIT=$?"` - the shell reported the echo's status,
# not Python's. Everything below exists to prevent a repeat.
#
#   set -u          an unset variable is an error, not an empty string
#   set -o pipefail the pipeline's status is the first non-zero member, so tee cannot mask
#                   a Python failure
#   PIPESTATUS[0]   Python's own status, read before anything else can overwrite it
#
# Deliberately NOT `set -e`: the status must be captured and reported, not cause an
# immediate exit that skips the reporting.

set -u
set -o pipefail

cd "$(dirname "$0")" || exit 2

RUNNER="run_production.py"
LOG="production.log"
CHECKPOINTS="p4_checkpoints_class_weight"

# Resume mode. The execution environment stops a backgrounded command after two hours,
# while this benchmark needs appreciably longer, so it must run in chunks. Resuming is NOT
# a relaxation of the clean-slate requirement: the first chunk started from an empty
# directory, every checkpoint carries a fingerprint over the data, partition, estimator and
# imbalance framework, and a checkpoint that does not match is refitted rather than reused.
# What resuming reuses is this same run's own output, from one source revision.
# Requires the log from the first chunk, so --resume cannot silently start a fresh run on
# top of someone else's checkpoints.
RESUME=0
if [ "${1:-}" = "--resume" ]; then
  RESUME=1
  if [ ! -f "$LOG" ]; then
    echo "ABORT: --resume given but $LOG is absent; there is no run to continue"
    exit 6
  fi
fi

echo "=== pre-flight ==="
date -u +"started %Y-%m-%dT%H:%M:%SZ"

# The checkpoint directory must not exist, or must be empty, and that fact is recorded
# here as well as in the execution manifest.
if [ -e "$CHECKPOINTS" ]; then
  COUNT=$(find "$CHECKPOINTS" -type f | wc -l)
  if [ "$COUNT" -ne 0 ] && [ "$RESUME" -eq 0 ]; then
    echo "ABORT: $CHECKPOINTS contains $COUNT files; a clean-slate run requires it empty"
    echo "       (pass --resume only to continue an interrupted run of this same revision)"
    exit 3
  fi
  if [ "$RESUME" -eq 1 ]; then
    echo "RESUMING an interrupted clean-slate run: $COUNT fingerprinted checkpoints present"
    echo "  mismatched checkpoints are refitted, not reused; failures are recorded"
  else
    echo "checkpoint directory exists and is empty"
  fi
else
  echo "checkpoint directory absent (clean slate)"
fi

# Refuse to run a reduced debugging configuration.
if grep -q "TRIMMED" "$RUNNER"; then
  echo "ABORT: $RUNNER carries a TRIMMED debugging marker"
  exit 4
fi
for REQUIRED in "RUN_FULL_BENCHMARK = True" "RUN_APPENDIX = True" \
                "IMBALANCE_STRATEGY = 'class_weight'"; do
  if ! grep -qF "$REQUIRED" "$RUNNER"; then
    echo "ABORT: $RUNNER is missing required setting: $REQUIRED"
    exit 5
  fi
  echo "verified: $REQUIRED"
done

echo "=== running $RUNNER ==="
# CD133_NOTEBOOK lets the manifest hash the notebook regardless of working directory.
CD133_NOTEBOOK="CD133_Cheminformatics_Colab.ipynb" \
  python3 -u "$RUNNER" 2>&1 | tee -a "$LOG"
STATUS=${PIPESTATUS[0]}

echo "=== post-run ==="
date -u +"finished %Y-%m-%dT%H:%M:%SZ"
echo "python exit status: $STATUS"
echo "checkpoints written: $(find "$CHECKPOINTS" -type f 2>/dev/null | wc -l)"

# A zero status is necessary but not sufficient: an analysis can exit cleanly having
# skipped work. Report the evidence either way and let it be inspected.
echo "--- completion evidence ---"
grep -aE "Repetitions configured|repetitions completed|Execution manifest written|Export complete|Skipped appendix" "$LOG" || echo "(no completion markers found)"
grep -acE "Traceback|AssertionError|NameError" "$LOG" | sed 's/^/error-signature lines: /'

exit "$STATUS"
