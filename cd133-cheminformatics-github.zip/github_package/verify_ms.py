"""Cross-check the generated manuscript against results_export/.

Extracts every number appearing in the manuscript body and tables, and confirms each
one is present in the exported result files (or is a structural number such as a table
index, year, reference number or page figure). Anything unaccounted for is reported so
it can be inspected; the goal is that no quantity reaches the paper without provenance.
"""
import json, os, re, sys
import pandas as pd
import numpy as np
import docx

R = sys.argv[1] if len(sys.argv) > 1 else 'results_export'
MS = sys.argv[2] if len(sys.argv) > 2 else 'Manuscript_J_Cheminformatics.docx'

# ---- gather every numeric value present anywhere in the exports ----
pool = set()


def add(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return
    if not np.isfinite(x):
        return
    for nd in range(0, 7):
        pool.add(f'{x:.{nd}f}')
    pool.add(str(int(x)) if float(x).is_integer() else '')
    if float(x).is_integer():
        pool.add(f'{int(x):,}')
    # percentage renderings
    for nd in (0, 1, 2):
        pool.add(f'{100*x:.{nd}f}')


def walk(o):
    if isinstance(o, dict):
        for v in o.values():
            walk(v)
    elif isinstance(o, (list, tuple)):
        for v in o:
            walk(v)
    else:
        add(o)


for fn in sorted(os.listdir(R)):
    p = os.path.join(R, fn)
    if fn.endswith('.json'):
        walk(json.load(open(p)))
    elif fn.endswith('.csv'):
        df = pd.read_csv(p)
        for c in df.columns:
            for v in df[c].tolist():
                add(v)
        for v in df.index.tolist():
            add(v)
pool.discard('')

# structural numbers that legitimately appear without being results
STRUCTURAL = set()
for i in range(0, 400):
    STRUCTURAL.add(str(i))           # table/figure/reference numbers, counts in prose
for y in range(1990, 2031):
    STRUCTURAL.add(str(y))
STRUCTURAL |= {'0.5', '0.8', '1.96', '2.5', '97.5', '80', '20', '95', '100',
               '1345199', '5', '1024', '1031', '4', '2300', '20059', '133'}
# Assay panel LABELS (not quantities) and software version strings.
STRUCTURAL |= {'206', '308', '827', '923'}
STRUCTURAL |= {'2026.09', '2025.09', '0.54', '3.0', '1.9', '2.5', '3.4', '0.14'}
# Raw table row count before metadata removal, derived as records + 10 in Methods.
STRUCTURAL |= {'15421', '15,421'}

doc = docx.Document(MS)
texts = [p.text for p in doc.paragraphs]
for t in doc.tables:
    for row in t.rows:
        for c in row.cells:
            texts.append(c.text)

# ignore the reference list and declarations block (DOIs, grant numbers, addresses)
body, in_refs = [], False
for t in texts:
    if t.strip() == 'References':
        in_refs = True
    if t.strip() == 'Figure legends':
        in_refs = False
    if not in_refs:
        body.append(t)
body_text = '\n'.join(body)
body_text = re.sub(r'\[INSERT[^\]]*\]', '', body_text)
body_text = re.sub(r'10\.\d{4,}/\S+', '', body_text)          # DOIs
body_text = re.sub(r'5U54CA\d+-\d+', '', body_text)           # grant number
body_text = re.sub(r'\b\d{4}\s?4th Street\b', '', body_text)

nums = re.findall(r'(?<![\w.])\d[\d,]*\.?\d*(?![\w])', body_text)
unmatched = []
for n in nums:
    clean = n.rstrip('.').replace(',', '')
    if not clean:
        continue
    if clean in STRUCTURAL or n in STRUCTURAL:
        continue
    if clean in pool or n in pool:
        continue
    # tolerate trailing-zero / rounding variants
    try:
        x = float(clean)
        if any(f'{x:.{d}f}' in pool for d in range(0, 7)):
            continue
    except ValueError:
        pass
    unmatched.append(n)

print(f'Manuscript: {MS}')
print(f'Exports scanned: {len(os.listdir(R))} files, {len(pool)} distinct numeric renderings')
print(f'Numbers found in manuscript body/tables: {len(nums)}')
print(f'Unaccounted-for numbers: {len(unmatched)}')
if unmatched:
    from collections import Counter
    for v, c in Counter(unmatched).most_common(40):
        print(f'   {v}  (x{c})')
else:
    print('  Every quantitative value traces to the results export.')
