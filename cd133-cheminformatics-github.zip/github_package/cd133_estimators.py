"""Estimators for the CD133 cheminformatics study.

Kept in a module rather than the notebook so that pickled checkpoints referencing these
classes can be reloaded without re-executing the notebook.
"""
import numpy as np
from xgboost import XGBClassifier


def balanced_sample_weight(y):
    """scikit-learn's class_weight='balanced' weights: w_c = n / (k * n_c)."""
    y = np.asarray(y)
    classes, counts = np.unique(y, return_counts=True)
    weight = {c: len(y) / (len(classes) * n) for c, n in zip(classes, counts)}
    return np.asarray([weight[v] for v in y], dtype=float)


class P4FoldBalancedXGBClassifier(XGBClassifier):
    """XGBoost with class_weight='balanced' semantics, derived per fit.

    scikit-learn applies class_weight='balanced' at fit time, so it is computed from
    whatever rows the estimator is being fitted on. XGBoost instead offers
    scale_pos_weight, which is fixed at construction - so deriving it from the full
    training partition would use labels from the validation fold. Computing the same
    balanced weights from the fit labels reproduces class_weight='balanced' exactly while
    remaining fold-contained.

    No constructor parameters are added, so grid-search keys, get_params and clone are
    unaffected.
    """

    def fit(self, X, y, **kwargs):
        assert 'sample_weight' not in kwargs, 'cost-sensitive weighting already set'
        return super().fit(X, y, sample_weight=balanced_sample_weight(y), **kwargs)
